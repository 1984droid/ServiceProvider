# 03 Service Layer Changes (Implementation)

## 1) Proposal creation
When generating proposals from defects:
- if mapping exists:
  - apply verb/noun/location
  - apply estimated costs/prices if provided
- else:
  - create fallback proposal (heuristic)
  - mark proposal.origin = FALLBACK

## 2) Approval workflow
- bulk_approve(proposal_ids, reviewer)
- bulk_reject(proposal_ids, reviewer, reason)
- bulk_promote_to_work_order(proposal_ids, target_work_order, reviewer)

## 3) Promotion logic
When promoting proposal → WorkOrderItem:
- copy estimated_unit_cost → unit_cost
- copy estimated_unit_price → unit_price
- copy estimated_labor_hours → labor_hours
- copy evidence_reference

Then:
- compute extended amounts
- recompute WO totals (or rely on signals/service call)

## 4) Completion hook
On WorkOrder completion:
- auto-resolve related defects
- for UNSAFE defects:
  - set requires_reinspection true
  - verification_status REQUIRED
  - create VerificationTask (optional)

## 5) Verification completion
When a follow-up InspectionRun is finalized (context=POST_REPAIR/RECHECK):
- for defects linked to that run:
  - set verification_status PASSED or FAILED
  - link verified_by_inspection_run
  - log DefectStateChange
