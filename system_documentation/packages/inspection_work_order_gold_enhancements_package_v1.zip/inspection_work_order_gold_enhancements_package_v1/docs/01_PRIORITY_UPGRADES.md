# 01 Priority Upgrades

## P0 (Safety + Leasing Confidence)
### 1) Post-repair verification loop for UNSAFE defects
Add:
- InspectionDefect.requires_reinspection (bool)
- InspectionDefect.verification_status (NOT_REQUIRED/REQUIRED/PASSED/FAILED)
- InspectionDefect.verified_by_inspection_run (FK nullable)
- InspectionDefect.verified_at (datetime nullable)

Behavior:
- When WO completes and resolves an UNSAFE defect:
  - mark defect status RESOLVED (to show work was performed)
  - set verification_status=REQUIRED
  - create a VerificationTask (optional) or queue an InspectionRunRequest

Leasing compliance:
- treat UNSAFE defects with verification_status=REQUIRED as still OUT_OF_SERVICE (or NONCOMPLIANT), depending on policy.

---

## P1 (Financial + Workflow Excellence)
### 2) Cost estimation on WorkOrderLineProposal
Add:
- estimated_unit_cost, estimated_unit_price
- estimated_labor_hours
- cost_type (same enum as WorkOrderItem)
Carry-over:
- When promoting proposal → WorkOrderItem, copy estimates into unit_cost/unit_price/labor_hours.

Sources for estimates:
- Parts catalog default costs/prices (if proposal references part_id)
- Labor operation rate book (optional)
- Seed mapping defaults (for standards-driven defects)

Outcome:
- instant “estimated repair cost” for customer approval
- consistent pricing

### 3) Batch create/approve/promote
Add:
- WorkOrderLineProposal.target_work_order (FK nullable)
- bulk approve/reject/promote actions
- “Create Work Order from selected proposals” transactional service method

Outcome:
- one click to turn 10 defects into 1 organized WO

---

## P2 (Auditability + Automation Coverage)
### 4) Defect lifecycle audit trail
Add DefectStateChange rows for:
- status changes (OPEN→DEFERRED, etc.)
- severity changes
- verification status changes
Record changed_by, reason, notes.

### 5) Fallback proposal generation + learning
When no mapping exists:
- create a conservative default proposal using heuristics (inspect/repair/replace verb selection by severity)
- allow service writer edits
- when promoted, optionally save a new mapping suggestion keyed by (template_key, step_key, rule_id/standard_reference)

---

## P3 (Nice-to-have, high UX value)
### 6) PM ↔ post-PM inspection linkage
MaintenanceProgram gains:
- requires_post_pm_inspection
- post_pm_inspection_program_key
On PM WO completion:
- auto-create a POST_PM InspectionRun (draft) or an InspectionDueInstance.

### 7) Evidence propagation to WorkOrderItem
Add WorkOrderItem.evidence_reference JSON:
- photos URLs/ids
- measurement summary
- defect notes/location
Do not duplicate blobs; reference existing attachments.
