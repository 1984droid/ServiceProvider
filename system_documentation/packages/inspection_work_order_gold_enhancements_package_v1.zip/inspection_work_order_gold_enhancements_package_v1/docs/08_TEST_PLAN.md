# 08 Test Plan

## Verification loop tests
- UNSAFE defect resolved by WO completion sets verification_status REQUIRED
- follow-up InspectionRun finalization sets PASSED or FAILED
- leasing compliance snapshot treats REQUIRED as not yet compliant

## Proposal estimates tests
- mapping-estimates carry to WorkOrderItem on promotion
- totals recompute correctly

## Batch workflow tests
- bulk approve/promote creates items in a single WO
- transaction rollback safety: partial promotion does not occur

## Audit trail tests
- DefectStateChange created for status/severity/verification transitions
