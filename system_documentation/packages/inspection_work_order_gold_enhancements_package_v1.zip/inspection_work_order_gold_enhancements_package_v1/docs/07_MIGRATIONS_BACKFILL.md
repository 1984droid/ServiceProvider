# 07 Migrations + Backfill

## Migrations
- Add fields to InspectionDefect (verification loop)
- Add fields to WorkOrderLineProposal (estimate + batching)
- Add DefectStateChange table
- Add evidence_reference to WorkOrderItem (if missing)
- Optional: add VerificationTask table

## Backfill
- No backfill required. Existing defects default verification_status=NOT_REQUIRED.
- Existing proposals default estimates to null.
