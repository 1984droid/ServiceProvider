# 06 API Endpoints (Suggested Additions)

## Proposals
- POST /api/inspections/{run_id}/proposals/generate
- POST /api/proposals/bulk-approve
- POST /api/proposals/bulk-reject
- POST /api/proposals/create-work-order
- POST /api/proposals/bulk-promote (to an existing WO)

## Verification
- GET /api/assets/{asset_id}/verification-tasks
- POST /api/verification-tasks/{id}/complete
- GET /api/defects/pending-verification

## Evidence
- WorkOrderItem should expose evidence_reference in detail endpoint (permissioned)
