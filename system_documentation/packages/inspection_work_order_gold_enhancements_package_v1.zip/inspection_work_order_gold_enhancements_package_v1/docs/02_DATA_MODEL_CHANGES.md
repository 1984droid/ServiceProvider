# 02 Data Model Changes (Additive)

## A) InspectionDefect
Add fields:
- requires_reinspection: bool
- verification_status: enum
- verified_by_inspection_run_id: FK nullable
- verified_at: datetime nullable

Optional:
- verification_required_reason (string short)
- verification_due_date (date) if you want due tracking

## B) WorkOrderLineProposal
Add fields:
- estimated_unit_cost, estimated_unit_price (decimal)
- estimated_labor_hours (decimal)
- cost_type (enum)
- target_work_order_id (FK nullable)
- evidence_reference (JSON) optional

## C) WorkOrderItem
Add:
- evidence_reference (JSON) optional (if not already present)

## D) DefectStateChange (new)
Append-only audit log:
- defect_id
- changed_at
- changed_by
- old/new: status, severity, verification_status
- reason, notes

## E) VerificationTask (optional)
If you want a queue for follow-up inspections:
- asset_id
- defect_id
- required_inspection_program_key (optional)
- status: OPEN/DONE/CANCELLED
- created_at, completed_at
