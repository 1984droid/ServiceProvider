# 00 Overview

## Current state (what you already have)
- InspectionDefect → WorkOrderLineProposal staging → WorkOrderItem
- Bidirectional traceability (WO links back to inspection run)
- Auto-proposal generation via seed mappings
- Auto-resolve defects on WO completion (MVP friendly)
- Strong tenant isolation checks

## Gold standard gaps (this package)
1) Verification loop for safety-critical fixes (repair must be verified)
2) Proposal stage lacks cost/pricing context (slows quoting + inconsistent estimates)
3) Batch workflow for multi-defect scenarios (service writer efficiency)
4) Defect lifecycle audit trail (who deferred/changed severity and why)
5) Automation coverage when no mapping exists (fallback heuristics + learn-from-use)
6) PM completion should optionally generate structured post-PM inspection
7) Evidence (photos/measurements) should be visible from WO items

## Design principles
- Keep human-in-the-loop staging.
- No silent unsafe closure: unsafe defects require verification when configured.
- Additive schema changes first; no breaking changes.
