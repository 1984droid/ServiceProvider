# 05 Financial + Quoting Hooks

## 1) Proposal estimates enable quoting
When proposals exist (approved or pending):
- compute estimated_total = sum(quantity * estimated_unit_price + labor_hours * labor_rate)
- show "estimated repairs" prior to creating a WO or invoice

## 2) Seamless promotion to billable items
Because proposal estimates carry over to WorkOrderItems, your existing:
- WorkOrder → Invoice (draft) logic
can now generate invoices with consistent line pricing without re-entry.

## 3) Price sources (recommended order)
- Part catalog defaults (part_id)
- Seed mapping defaults (per defect template)
- Tenant PriceBook overrides (future)
- Manual override at proposal stage (tracked in audit log)
