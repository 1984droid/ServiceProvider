# 04 Leasing Compliance Hooks

This integrates directly with the Leasing Compliance Monitoring package.

## 1) Compliance status for unsafe defects
Policy rule:
- If defect.severity == UNSAFE_OUT_OF_SERVICE and defect.status != RESOLVED -> OUT_OF_SERVICE
- If defect.status == RESOLVED but defect.verification_status == REQUIRED -> OUT_OF_SERVICE (or NONCOMPLIANT)
- If defect.verification_status == FAILED -> OUT_OF_SERVICE

## 2) Leasing dashboard fields
- count of unsafe defects pending verification
- list of VerificationTasks (if used)
- last verified repair date

## 3) Sharing permissions
Leasing should see:
- defect severity/status/verification status
- linked work order summary
Evidence and costs are permission-gated.
