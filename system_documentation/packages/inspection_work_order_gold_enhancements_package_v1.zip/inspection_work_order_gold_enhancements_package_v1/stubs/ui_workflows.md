# UI Workflows (recommended)

## Service writer: multi-defect repair workflow
1) Open InspectionRun → view defects list
2) Click "Generate proposals" (bulk)
3) Review proposals in a table:
   - verb/noun/location
   - estimated cost/price
   - evidence preview thumbnail(s)
4) Select proposals → "Create Work Order" (one click)
5) Work order opens with items already priced and prioritized

## Verification workflow
1) Work order completes with UNSAFE items
2) Asset shows "Pending Verification" banner
3) Quick recheck inspection is created (draft)
4) Inspector completes recheck
5) Defect verification status becomes PASSED/FAILED
