# Services pseudocode (core flows)

## resolve_defects_on_work_order_completion(work_order)
for defect in related_defects(work_order):
  old_status = defect.status
  defect.status = 'RESOLVED'
  defect.resolved_at = now()
  defect.resolved_by_work_order = work_order

  # verification gate for unsafe
  if defect.severity == 'UNSAFE_OUT_OF_SERVICE':
      defect.requires_reinspection = True
      defect.verification_status = 'REQUIRED'

  defect.save()
  DefectStateChange.create(old_status=old_status, new_status=defect.status, old_verification_status=..., new_verification_status=...)

## promote_proposal_to_item(proposal, work_order)
item = WorkOrderItem.create(
  unit_cost=proposal.estimated_unit_cost,
  unit_price=proposal.estimated_unit_price,
  labor_hours=proposal.estimated_labor_hours,
  evidence_reference=proposal.evidence_reference,
  related_defect=proposal.related_defect,
  ...
)
item.compute_extended_amounts()
work_order.recompute_totals()

## bulk_create_work_order_from_proposals(asset, proposal_ids)
with transaction.atomic():
  wo = WorkOrder.create(asset=asset, summary="Inspection Repairs", status='OPEN')
  for p in proposals:
    promote_proposal_to_item(p, wo)
  proposals.update(status='promoted', target_work_order=wo)
return wo

## verify_defects_from_recheck_inspection(inspection_run)
# based on recheck results:
for defect in defects_addressed:
  defect.verification_status = 'PASSED' or 'FAILED'
  defect.verified_by_inspection_run = inspection_run
  defect.verified_at = now()
  defect.save()
  DefectStateChange.create(...)
