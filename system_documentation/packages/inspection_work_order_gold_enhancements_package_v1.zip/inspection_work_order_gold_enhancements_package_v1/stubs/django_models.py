# Django model stubs (additive)

from django.db import models
from django.utils import timezone

class InspectionDefect(models.Model):
    # existing: status (OPEN/RESOLVED/DEFERRED), severity, resolved_by_work_order, resolved_at, photos, notes, etc.

    requires_reinspection = models.BooleanField(default=False)
    verification_status = models.CharField(
        max_length=20,
        default='NOT_REQUIRED',
        choices=[
            ('NOT_REQUIRED','Not Required'),
            ('REQUIRED','Required'),
            ('PASSED','Passed'),
            ('FAILED','Failed'),
        ]
    )
    verified_by_inspection_run = models.ForeignKey('inspections.InspectionRun', null=True, blank=True, on_delete=models.SET_NULL, related_name='verified_defects')
    verified_at = models.DateTimeField(null=True, blank=True)

class WorkOrderLineProposal(models.Model):
    # existing fields: related_defect, verb, noun_item, service_location, quantity, priority, status, etc.

    estimated_unit_cost = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    estimated_unit_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    estimated_labor_hours = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    cost_type = models.CharField(max_length=24, default='CUSTOMER_BILLABLE')

    target_work_order = models.ForeignKey('work_orders.WorkOrder', null=True, blank=True, on_delete=models.SET_NULL, related_name='pending_proposals')
    evidence_reference = models.JSONField(default=dict, blank=True)

class WorkOrderItem(models.Model):
    # if not already present:
    evidence_reference = models.JSONField(default=dict, blank=True)

class DefectStateChange(models.Model):
    defect = models.ForeignKey('inspections.InspectionDefect', on_delete=models.CASCADE, related_name='state_changes')
    changed_at = models.DateTimeField(auto_now_add=True)
    changed_by = models.ForeignKey('users.Membership', null=True, blank=True, on_delete=models.SET_NULL)

    old_status = models.CharField(max_length=20, blank=True)
    new_status = models.CharField(max_length=20, blank=True)
    old_severity = models.CharField(max_length=50, blank=True)
    new_severity = models.CharField(max_length=50, blank=True)
    old_verification_status = models.CharField(max_length=20, blank=True)
    new_verification_status = models.CharField(max_length=20, blank=True)

    reason = models.CharField(max_length=200, blank=True)
    notes = models.TextField(blank=True)
