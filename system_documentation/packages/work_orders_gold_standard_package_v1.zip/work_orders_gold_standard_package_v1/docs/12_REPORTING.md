# 12 Reporting (Premium Outputs)

## Asset spend
- Total spend by asset (12 months)
- Spend by category (parts/labor/sublet/fees/insurance/etc.)
- PM vs reactive spend split
- Cost per mile / hour

## Operational
- Work order volume by noun category
- Repeat defect patterns (noun + location)
- Mean time between failures by subtype

## Leasing
- Compliance rollups (COMPLIANT/DUE_SOON/OVERDUE/OOS)
- Proof drilldown: which programs fulfilled, by which provider
- Optional spend summaries (if permitted)
