# 10 Migrations & Backfill

## Strategy
- Additive changes only where possible
- All new fields nullable initially
- Backfill progressively
- Use management commands for recompute/backfill

## Recommended migration order
1) WorkOrder / WorkOrderItem new fields (financials + timestamps + maintenance linkage)
2) MaintenanceDueInstance
3) AssetCostEvent ledger
4) DefectResolution
5) Part model

## Backfill steps
- WorkOrder totals:
  - set to 0.00 for existing work orders
  - recompute totals only when items have costs
- Maintenance linkage:
  - existing work orders remain unlinked unless manually tagged
- Ledger:
  - emit ledger events only for completed work orders after a cutover date OR
  - run backfill to create ledger rows from historic work orders (optional)

## Safety
- Provide a --validate-only mode for config imports
- Wrap import/backfill per tenant in transactions when possible
- Maintain idempotent ledger emission (unique constraint on (source_type, source_id, category))
