# 05 Asset Cost Ledger (Design)

## Objective
Provide unified spend reporting per asset WITHOUT forcing everything through work orders.

## AssetCostEvent
The ledger is the system of record for cost analytics.

### Sources
- WORK_ORDER: emitted from completed work orders
- MANUAL_EXPENSE: entered directly (insurance, registration, tax, tolls, etc.)
- INVOICE: imported from AP/AR (optional)
- CAPEX: capital improvements (may affect asset value)

### Categories
Use controlled expense_category enum, examples:
- PARTS
- LABOR
- SUBLET
- FEES
- CONSUMABLES
- INSURANCE
- REGISTRATION
- TAX
- LEASE_PAYMENT
- FUEL
- TIRES
- OTHER

### Dual amounts
- amount_cost: internal/shop cost (optional if unknown)
- amount_price: billed/paid amount (optional)
Many use cases need both.

## WorkOrder emission strategy
Option A: Emit one ledger event per WorkOrderItem (granular)
Option B: Emit one event per bucket (parts/labor/sublet/fees) with a link to WorkOrder
MVP recommendation: bucketed events (fewer rows), keep link to WO for drilldown.

## Permissions + leasing
AssetCostEvent should be permission-gated by SharingContract.
Leasing typically sees:
- summary totals by category and time period
- not necessarily unit costs
But allow optional full cost sharing with explicit grant.
