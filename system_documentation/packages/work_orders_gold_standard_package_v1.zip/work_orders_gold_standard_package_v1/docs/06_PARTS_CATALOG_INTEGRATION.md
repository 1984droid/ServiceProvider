# 06 Parts Catalog Integration (Design)

## Goal
Auto-populate WorkOrderItem unit_cost/unit_price and improve reporting.

## Part model (minimum)
- noun_item_id (required): ties part to your structured vocabulary
- part_number
- description
- unit_cost_default
- unit_price_default
- vendor_id (optional)
- is_serialized
- is_active

## WorkOrderItem behavior
If noun_item.type == PART:
- part_id should be required (unless you explicitly allow "generic part")
- unit_cost/unit_price default from Part, override allowed with permission

## Future (optional)
- quantity_on_hand, stock movements, PO receiving
- serialized unit tracking
