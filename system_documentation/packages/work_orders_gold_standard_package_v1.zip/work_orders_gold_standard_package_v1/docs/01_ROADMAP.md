# 01 Roadmap (Agent Implementation Plan)

This roadmap is structured as deliverable phases with acceptance criteria. 
It assumes your current WO model exists and is additive-only where possible.

---

## Phase 1 — Financial Layer for Work Orders (CRITICAL)
### Goals
- Track internal shop cost vs customer billable price
- Support warranty/internal/capital classifications
- Enable asset spend rollups, invoicing readiness

### Tasks
1. Add costing fields to WorkOrderItem:
   - quantity, uom
   - unit_cost, extended_cost
   - unit_price, extended_price
   - cost_type (CUSTOMER_BILLABLE / INTERNAL_SHOP / WARRANTY / CAPITALIZED / GOODWILL)
   - is_billable (derived or explicit)
   - labor_hours (optional; required for LABOR lines)

2. Add cached totals to WorkOrder:
   - internal_cost_total
   - billable_price_total
   - total_parts_cost, total_labor_cost, total_fees_cost, total_sublet_cost (optional but recommended)
   - completed_at timestamps (see Phase 3 if you want to split)

3. Add single source of truth computation service:
   - recompute_work_order_totals(work_order_id)

### Acceptance Criteria
- Can answer: "total internal cost on this WO"
- Can answer: "total billable on this WO"
- Totals stay consistent when items are created/updated/deleted

---

## Phase 2 — Maintenance Program Integration (CRITICAL for leasing)
### Goals
- Tie PM work to program keys and due instances
- Enable on-time compliance computation

### Tasks
1. Add WorkOrder fields:
   - maintenance_program_id (nullable)
   - is_preventive_maintenance
   - scheduled_date (or scheduled_window_start/end)
   - meter_reading_at_service

2. Add MaintenanceDueInstance:
   - due_date / due_meter
   - status DUE/SCHEDULED/IN_PROGRESS/DONE/SKIPPED
   - fulfilled_by_work_order_id

3. Auto-create WO proposals from due instances:
   - PM tasks -> suggested structured lines

### Acceptance Criteria
- Can answer: "was 15k PM done on time?"
- Can compute: overdue days/hours/miles per program

---

## Phase 3 — Workflow Timestamps + Provider Identity (HIGH)
### Goals
- Measure downtime and service latency
- Support leasing view: who serviced it and when it was completed

### Tasks
- Add WorkOrder.started_at / completed_at
- Auto-set timestamps on status changes
- Ensure WorkOrder exposes serviced_by_tenant (already present in asset models in your system)

### Acceptance Criteria
- Can compute: out-of-service duration
- Leasing can show: last service completion date (summary)

---

## Phase 4 — Asset Cost Ledger (CRITICAL for “exceptional”)
### Goals
- Single unified spend reporting across sources
- Work orders are one source; allow non-WO expenses

### Tasks
1. Add AssetCostEvent ledger:
   - asset_id
   - event_date
   - source_type (WORK_ORDER, MANUAL_EXPENSE, INVOICE, INSURANCE, REGISTRATION, TAX, LEASE_PAYMENT, CAPEX, OTHER)
   - source_id (nullable)
   - amount_cost, amount_price (optional)
   - expense_category (controlled enum)
   - payer_org / payee_vendor (refs)
   - cost_type (same enum as WO)

2. Emit ledger events from WorkOrder completion:
   - either per item (granular) OR per bucket (parts/labor/sublet) with detail link
   - idempotent emission (do not duplicate)

3. Create manual AssetExpense workflow:
   - create AssetCostEvents for non-WO spend

### Acceptance Criteria
- Can answer: "12-month total spend per asset"
- Can split PM vs reactive (via maintenance_program_id / is_preventive_maintenance)
- Can include insurance/registration/etc.

---

## Phase 5 — Defect Resolution Loopback (MEDIUM)
### Goals
- Close inspection → repair → verification

### Tasks
- Add DefectResolution linking defects to work done
- Optionally require reinspection for closure

### Acceptance Criteria
- Leasing can see: unsafe defect has been addressed and verified

---

## Phase 6 — Parts Catalog Integration (MEDIUM)
### Goals
- Reduce cost entry errors
- Link parts to nouns for reporting

### Tasks
- Add Part model referencing noun_item
- WorkOrderItem.part_id required when noun_item.type == PART
- Auto-fill unit_cost/unit_price from Part defaults, allow override with permission

### Acceptance Criteria
- Parts cost auto-populates
- Reporting by noun category becomes accurate

---

## Phase 7 — Leasing Integration (depends on leasing package)
### Goals
- Leasing tenant can read-only monitor compliance and optionally cost summaries

### Tasks
- Reuse SharingContract permissioning
- Add leasing endpoints that query:
  - AssetComplianceSnapshot
  - WorkOrder summary / maintenance fulfillment
  - (optional) AssetCostEvent summary

### Acceptance Criteria
- Leasing sees COMPLIANT/DUE_SOON/OVERDUE/OOS with explainable reasons
- Cost visibility is permission-gated (none/summary/full)

