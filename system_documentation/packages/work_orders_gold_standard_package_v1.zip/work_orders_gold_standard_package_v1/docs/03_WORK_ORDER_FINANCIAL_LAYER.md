# 03 Work Order Financial Layer (Design)

## Goals
- Track internal cost AND billable price
- Classify each line for reporting and permissions
- Support warranty/internal/capitalized work

## Noun Type Expansion
Recommended noun_item_type enum:
- PART
- LABOR
- CONSUMABLE
- FEE
- SUBLET

This enables correct totals and reporting.

## Cost & Price Semantics
- unit_cost: what it costs the performing tenant/shop
- unit_price: what is charged to payer (customer), if billable
- extended_cost = quantity * unit_cost
- extended_price = quantity * unit_price

## Cost Type (financial classification)
Use a stable enum shared across ledger and work orders:
- CUSTOMER_BILLABLE
- INTERNAL_SHOP
- WARRANTY
- CAPITALIZED
- GOODWILL

## Permissions
Costs are sensitive. Recommended permission levels:
- none: cannot see unit_cost/unit_price
- summary: can see totals (internal_cost_total, billable_price_total) but not item detail
- full: can see item-level costs/prices

Leasing integration should default to none or summary, controlled by SharingContract permissions.

## Implementation notes
- Store decimals with adequate precision (e.g., max_digits=12, decimal_places=2)
- All totals should be computed in one service method to avoid drift.
- On WorkOrder completion: freeze totals (optional), then emit ledger events.
