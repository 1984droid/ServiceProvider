# 07 Defect Resolution and Recheck (Design)

## Problem
Today: defect → proposal → work order item exists, but defect doesn't automatically become resolved/verified.

## Solution
Add DefectResolution and (optionally) Verification.

### DefectResolution
- defect_id
- resolved_by_work_order_item_id or work_order_id
- resolution: FIXED / TEMP / DEFERRED / REQUIRES_RECHECK
- resolved_at
- verification_status: PENDING / VERIFIED
- verified_by_inspection_run_id (nullable)

### Workflow
1) Defect creates proposals
2) Proposals become WO items
3) When WO item completed:
   - create DefectResolution in PENDING
4) If requires recheck:
   - schedule follow-up inspection program or a quick recheck checklist
5) When recheck inspection passes:
   - mark VERIFIED

## Leasing integration
Leasing compliance status:
- OUT_OF_SERVICE if unsafe defects exist without VERIFIED resolution
