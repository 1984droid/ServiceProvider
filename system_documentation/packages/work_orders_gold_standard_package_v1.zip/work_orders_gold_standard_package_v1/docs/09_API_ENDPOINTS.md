# 09 API Endpoints (Proposed)

## Core Work Orders
- GET /api/work-orders/
- POST /api/work-orders/
- GET /api/work-orders/{id}/
- PATCH /api/work-orders/{id}/

## Financial summaries
- GET /api/work-orders/{id}/totals/
- GET /api/assets/{asset_id}/work-orders/summary/?from=&to=

## Maintenance linkage
- GET /api/maintenance-due/?asset_id=
- POST /api/maintenance-due/{id}/schedule-work-order/  (creates proposal/WO)
- GET /api/work-orders/?maintenance_program_id=

## Asset cost ledger
- GET /api/assets/{asset_id}/cost-ledger/?from=&to=&category=
- POST /api/assets/{asset_id}/cost-ledger/manual-expense/
- GET /api/reports/assets/cost-by-category/?from=&to=&subtype=

## Leasing endpoints (read-only, SharingContract gated)
- GET /api/leasing/assets/{asset_id}/maintenance-history/  (summary)
- GET /api/leasing/assets/{asset_id}/cost-summary/         (if asset_costs allowed)
- GET /api/leasing/assets/overdue-maintenance/
