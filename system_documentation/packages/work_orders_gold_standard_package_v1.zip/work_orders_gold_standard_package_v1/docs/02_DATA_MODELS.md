# 02 Data Models (Proposed)

This doc describes additive changes to reach "gold standard".

## A) Work Orders

### WorkOrder (add fields)
- started_at: datetime nullable
- completed_at: datetime nullable
- maintenance_program_id: FK nullable
- is_preventive_maintenance: bool default false
- scheduled_date: date nullable
- meter_reading_at_service: int nullable
- internal_cost_total: decimal cached
- billable_price_total: decimal cached
- cost_totals_by_bucket: JSON optional (parts/labor/sublet/fees)

### WorkOrderItem (add fields)
- noun_item_type: derived from noun_item OR stored for speed
- uom: enum
- unit_cost, extended_cost
- unit_price, extended_price
- cost_type: enum
- is_billable: bool
- labor_hours: decimal nullable

## B) Maintenance Due

### MaintenanceDueInstance (new)
- asset_id
- program_id
- due_date nullable
- due_meter nullable
- status enum
- fulfilled_by_work_order_id nullable
- created_at, updated_at

## C) Asset Cost Ledger

### AssetCostEvent (new)
- asset_id
- event_date
- source_type enum
- source_id (uuid nullable)
- expense_category enum
- cost_type enum
- amount_cost (shop/internal cost)
- amount_price (what customer paid / billed amount) nullable
- payer_organization_id nullable
- payee_vendor_id nullable
- notes (short) optional
- created_at

### ExpenseDocument + Allocation (optional but excellent)
- ExpenseDocument: invoice metadata, vendor, date, total, attachments
- ExpenseAllocationLine: document_id, asset_id, amount, category

## D) Defect Resolution

### DefectResolution (new)
- defect_id
- resolved_by_work_order_id (or work_order_item_id)
- resolution enum (FIXED/TEMP/DEFERRED/REQUIRES_RECHECK)
- resolved_at
- verification_status (PENDING/VERIFIED)
- verified_by_inspection_run_id nullable

## E) Provider Verification
- Tenant.is_verified_provider (bool)
- Tenant.certifications (JSON list)
