# 11 Test Plan (Must-have)

## Financial layer tests
- extended_cost = qty * unit_cost
- extended_price = qty * unit_price
- totals recompute correctly across add/update/delete items
- permission gating: who can see unit_cost/unit_price vs totals

## Maintenance linkage tests
- due instance created from program assignment
- work order completion marks due instance DONE
- meter-based and time-based due logic

## Ledger tests
- work order completion emits idempotent cost events
- manual expense creates ledger event
- sum of ledger events equals asset spend report output

## Defect resolution tests
- completing WO item creates resolution PENDING
- recheck inspection marks VERIFIED
- unsafe defect without VERIFIED resolution => OOS in compliance snapshot

## Leasing integration tests (security critical)
- without SharingContract: leasing sees nothing
- with summary permissions: leasing sees only summary fields
- evidence/cost access requires explicit permissions
- access logs written for each view/export
