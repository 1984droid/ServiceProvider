# 04 Maintenance Due Integration (Design)

## Why it matters
This is required to compute compliance correctly (especially for leasing):
- "Was PM done on time?"
- "How overdue is this asset?"

## Recommended model: MaintenanceDueInstance
- Create due instances whenever:
  - an asset is assigned a maintenance program
  - meter is updated and causes next due to be determinable
- Each instance can be fulfilled by a WorkOrder (or marked skipped with reason)

## WorkOrder linkage
WorkOrder should store:
- maintenance_program_id (nullable)
- meter_reading_at_service
- is_preventive_maintenance
- completed_at

When WorkOrder is completed:
- find nearest due instance (same program, within window)
- mark it DONE and link work order

## PM work order proposals
Generate suggested structured lines:
- nouns + verbs based on the maintenance program tasks
- allow service writer to approve (reuse existing proposals pattern)

## Leasing integration
LeasePolicy requires PM compliance by program key patterns.
Compliance engine:
- checks due instances (DONE vs overdue)
- does not need to infer from dates only
