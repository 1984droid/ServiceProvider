# 08 Leasing Integration Notes (Work Orders + Spend)

This doc describes how this work order upgrade integrates with the Leasing Compliance Monitoring system.

## 1) SharingContract drives visibility
Leasing access to work orders and cost ledger is always gated by SharingContract.
No grant -> compliance UNKNOWN; no work orders visible.

## 2) Permissions matrix extensions
Extend SharingContract.permissions to include cost visibility:
- work_orders: none|summary|full
- asset_costs: none|summary|full
- provider_identity: true|false

Recommended defaults:
- work_orders: summary
- asset_costs: summary OR none (customer choice)
- provider_identity: true

## 3) What leasing needs from work orders (summary)
For compliance and residual value, leasing needs:
- completed_at
- is_preventive_maintenance
- maintenance_program_id (or program key)
- meter_reading_at_service
- serviced_by_tenant (provider identity + verified badge)

Leasing does NOT need:
- free text notes (optional)
- item-level cost details (unless explicitly granted)

## 4) Compliance engine linkage
AssetComplianceSnapshot should use:
- MaintenanceDueInstance DONE status (fulfilled by work order)
- InspectionRun finalized results and defect resolution status
- Provider verification status for the work that fulfilled requirements

## 5) Spend reporting linkage
Asset cost reporting should use AssetCostEvent, not raw work orders.
WorkOrder completion emits ledger events. Leasing consumes ledger summary if allowed.

## 6) Privacy stance
Costs are sensitive. Allow customers to grant:
- summary totals only (recommended)
- full detail (rare, explicit contracts)
Always log access.
