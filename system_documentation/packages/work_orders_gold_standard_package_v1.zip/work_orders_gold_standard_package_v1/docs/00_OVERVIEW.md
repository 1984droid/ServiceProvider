# 00 Overview

## What exists today (per assessment)
- Strong structured vocabulary (noun/verb/location)
- Inspection → Work Order proposal workflow
- Asset linkage and multi-tenant isolation
- Missing: financial/cost layer, maintenance program linkage, parts integration, cross-tenant sharing for leasing

## Gold Standard Target
1) Every WorkOrderItem has money semantics (cost and/or price)
2) Work orders can fulfill scheduled maintenance due instances
3) Defects can be resolved and optionally rechecked
4) Asset spend reporting uses one ledger across multiple sources (WO + non-WO expenses)
5) Leasing can monitor compliance and (optionally) spending, using SharingContract permissions

## Philosophy
- Keep structured vocab: verb+noun+location remains the operational backbone.
- Add accounting-grade classification: PART/LABOR/CONSUMABLE/FEE/SUBLET.
- Never force all expenses through work orders: allow direct asset expenses.
- Default deny cross-tenant visibility; SharingContract is required.
