# Django model skeletons (stubs)
# Adapt to your project; fields shown are the "gold standard" additions.

from django.db import models
from django.utils import timezone

class WorkOrder(models.Model):
    # existing fields: tenant_root, asset, status, summary, description, etc.
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    maintenance_program = models.ForeignKey('assets.MaintenanceProgram', on_delete=models.SET_NULL, null=True, blank=True)
    is_preventive_maintenance = models.BooleanField(default=False)
    scheduled_date = models.DateField(null=True, blank=True)
    meter_reading_at_service = models.IntegerField(null=True, blank=True)

    internal_cost_total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    billable_price_total = models.DecimalField(max_digits=12, decimal_places=2, default=0)

class WorkOrderItem(models.Model):
    work_order = models.ForeignKey(WorkOrder, on_delete=models.CASCADE, related_name='items')

    noun_item = models.ForeignKey('work_orders.NounItem', on_delete=models.PROTECT)
    verb = models.ForeignKey('work_orders.Verb', on_delete=models.PROTECT)
    service_location = models.ForeignKey('work_orders.ServiceLocation', on_delete=models.PROTECT, null=True, blank=True)

    quantity = models.DecimalField(max_digits=10, decimal_places=2, default=1)
    uom = models.CharField(max_length=16, default='each')

    noun_item_type = models.CharField(max_length=16, default='SERVICE')  # or derived from noun_item
    cost_type = models.CharField(max_length=24, default='CUSTOMER_BILLABLE')
    is_billable = models.BooleanField(default=True)

    unit_cost = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    extended_cost = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    extended_price = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    labor_hours = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)

    related_defect = models.ForeignKey('inspections.InspectionDefect', on_delete=models.SET_NULL, null=True, blank=True)

class MaintenanceDueInstance(models.Model):
    asset = models.ForeignKey('assets.Asset', on_delete=models.CASCADE)
    program = models.ForeignKey('assets.MaintenanceProgram', on_delete=models.CASCADE)
    due_date = models.DateField(null=True, blank=True)
    due_meter = models.IntegerField(null=True, blank=True)

    status = models.CharField(max_length=16, default='DUE')
    fulfilled_by_work_order = models.ForeignKey(WorkOrder, on_delete=models.SET_NULL, null=True, blank=True)

class AssetCostEvent(models.Model):
    asset = models.ForeignKey('assets.Asset', on_delete=models.CASCADE)
    event_date = models.DateField(default=timezone.now)

    source_type = models.CharField(max_length=24)
    source_id = models.UUIDField(null=True, blank=True)

    expense_category = models.CharField(max_length=32)
    cost_type = models.CharField(max_length=24, default='CUSTOMER_BILLABLE')

    amount_cost = models.DecimalField(max_digits=12, decimal_places=2)
    amount_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)

    notes = models.CharField(max_length=240, blank=True)

class DefectResolution(models.Model):
    defect = models.ForeignKey('inspections.InspectionDefect', on_delete=models.CASCADE)
    resolved_by_work_order = models.ForeignKey(WorkOrder, on_delete=models.SET_NULL, null=True, blank=True)

    resolution = models.CharField(max_length=24)
    resolved_at = models.DateTimeField(default=timezone.now)

    verification_status = models.CharField(max_length=16, default='PENDING')
    verified_by_inspection_run = models.ForeignKey('inspections.InspectionRun', on_delete=models.SET_NULL, null=True, blank=True)
