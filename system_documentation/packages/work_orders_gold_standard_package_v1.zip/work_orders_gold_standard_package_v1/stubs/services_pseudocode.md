# Services (Pseudocode)

## recompute_work_order_item_amounts(item)
- if unit_cost is not null: extended_cost = quantity * unit_cost
- else extended_cost = 0
- if unit_price is not null: extended_price = quantity * unit_price
- else extended_price = 0

## recompute_work_order_totals(work_order)
- sum item.extended_cost into internal_cost_total
- sum item.extended_price where item.is_billable into billable_price_total
- optionally compute bucket totals based on noun_item_type
- persist on WorkOrder

## emit_ledger_events_from_work_order(work_order)
- only when work_order.completed_at set (or status COMPLETE)
- idempotency: unique key (source_type='WORK_ORDER', source_id=work_order.id, expense_category=<bucket>)
- compute bucket totals and create/update AssetCostEvent rows

## mark_due_instance_done(work_order)
- if work_order.maintenance_program:
  - find nearest due instance for asset+program in DUE/SCHEDULED/IN_PROGRESS
  - link and mark DONE

## close_defects_for_completed_items(work_order)
- for each item with related_defect:
  - create DefectResolution(PENDING)
  - if policy requires recheck: set REQUIRES_RECHECK

## leasing_visibility_filter(user, queryset)
- if user.tenant is leasing_company:
  - filter assets/workorders/cost events by active SharingContracts
  - redact fields based on SharingContract.permissions (summary/full)
  - log access
