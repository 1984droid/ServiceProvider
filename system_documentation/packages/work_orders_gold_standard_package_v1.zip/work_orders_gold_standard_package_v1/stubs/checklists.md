# Checklists

## Migration checklist
- Add nullable fields
- Deploy
- Backfill totals (optional)
- Enable cost entry in UI
- Enable ledger emission on completion
- Monitor for duplicate ledger events (idempotency)

## Leasing integration checklist
- Extend SharingContract permissions with work_orders + asset_costs levels
- Add leasing endpoints that only use visibility-filtered querysets
- Ensure access logs are written
- Add tests: deny by default; allow with grant

## Go-live checklist
- Ensure required fields enforced (uom, quantity, cost_type)
- Ensure status transitions set timestamps
- Ensure compliance engine reads due instances + completed work orders
