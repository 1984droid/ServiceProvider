# Work Orders Gold Standard Package (v1)

Generated: 2026-02-08

This package is a **build roadmap + schema kit** to take your current Work Order system from:
"Operationally strong but missing financial + maintenance linkage"
to:
"Gold standard: operational execution + scheduled maintenance fulfillment + unified asset spend ledger"

It is designed to integrate cleanly with:
- **Inspection system** (defects → proposals → work order items)
- **Maintenance programs** (time/meter scheduling)
- **Leasing compliance monitoring** (SharingContracts + read-only dashboards + compliance snapshots)

Core idea:
- Work Orders capture *work performed* (service + parts + labor + sublet).
- A unified **Asset Cost Ledger** captures *all asset spend* (work orders + non-work-order expenses).
- Leasing consumes **compliance state** and (optionally) **cost summaries**, gated by SharingContract permissions.

## Contents
- docs/00_OVERVIEW.md
- docs/01_ROADMAP.md
- docs/02_DATA_MODELS.md
- docs/03_WORK_ORDER_FINANCIAL_LAYER.md
- docs/04_MAINTENANCE_DUE_INTEGRATION.md
- docs/05_ASSET_COST_LEDGER.md
- docs/06_PARTS_CATALOG_INTEGRATION.md
- docs/07_DEFECT_RESOLUTION_AND_RECHECK.md
- docs/08_LEASING_INTEGRATION_NOTES.md
- docs/09_API_ENDPOINTS.md
- docs/10_MIGRATIONS_BACKFILL.md
- docs/11_TEST_PLAN.md
- docs/12_REPORTING.md

- schemas/*.schema.json
- stubs/django_models.py
- stubs/services_pseudocode.md
- stubs/openapi_stub.yaml
- stubs/checklists.md

## Implementation Order (high level)
1) Work order financial fields + totals
2) Maintenance linkage + due instances
3) Asset cost ledger + WO-to-ledger emission
4) Defect resolution loopback
5) Parts catalog integration (optional for MVP, recommended soon)
6) Leasing read-only views (SharingContract gated) + compliance rollups

