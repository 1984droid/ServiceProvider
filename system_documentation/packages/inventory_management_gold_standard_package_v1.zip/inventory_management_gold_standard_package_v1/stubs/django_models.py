# Django model skeletons (stubs) — Inventory system
# Adapt import paths and existing model names to your project.

from django.db import models
from django.utils import timezone

class Vendor(models.Model):
    tenant_root = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    name = models.CharField(max_length=160)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=40, blank=True)
    terms = models.CharField(max_length=32, blank=True)  # net30, etc.
    is_active = models.BooleanField(default=True)

class Part(models.Model):
    tenant_root = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    sku = models.CharField(max_length=64)
    barcode_upc = models.CharField(max_length=64, blank=True)
    noun_item = models.ForeignKey('work_orders.NounItem', on_delete=models.PROTECT)
    description = models.CharField(max_length=200)
    base_uom = models.CharField(max_length=16, default='each')

    is_stocked = models.BooleanField(default=True)
    is_serialized = models.BooleanField(default=False)

    default_unit_cost = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    default_unit_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)

    is_rebuildable = models.BooleanField(default=False)
    core_part = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL, related_name='reman_parts')
    core_charge_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    core_due_days = models.IntegerField(default=30)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['tenant_root','sku'], name='uq_part_sku_per_tenant')
        ]

class InventoryLocation(models.Model):
    tenant_root = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    name = models.CharField(max_length=120)
    code = models.CharField(max_length=40)
    location_type = models.CharField(max_length=16, default='WAREHOUSE')
    parent_location = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL)

    assigned_to_asset = models.ForeignKey('assets.Asset', null=True, blank=True, on_delete=models.SET_NULL)
    is_active = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['tenant_root','code'], name='uq_location_code_per_tenant')
        ]

class InventoryStock(models.Model):
    tenant_root = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    part = models.ForeignKey(Part, on_delete=models.CASCADE)
    location = models.ForeignKey(InventoryLocation, on_delete=models.CASCADE)

    on_hand_qty = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    reserved_qty = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    updated_at = models.DateTimeField(auto_now=True)

    @property
    def available_qty(self):
        return self.on_hand_qty - self.reserved_qty

class InventoryTransaction(models.Model):
    tenant_root = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    occurred_at = models.DateTimeField(default=timezone.now)

    part = models.ForeignKey(Part, on_delete=models.PROTECT)
    quantity = models.DecimalField(max_digits=12, decimal_places=2)

    from_location = models.ForeignKey(InventoryLocation, null=True, blank=True, on_delete=models.SET_NULL, related_name='outgoing_txns')
    to_location = models.ForeignKey(InventoryLocation, null=True, blank=True, on_delete=models.SET_NULL, related_name='incoming_txns')

    transaction_type = models.CharField(max_length=24)
    source_type = models.CharField(max_length=32, blank=True)
    source_id = models.UUIDField(null=True, blank=True)

    unit_cost = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    notes = models.CharField(max_length=240, blank=True)

class PurchaseOrder(models.Model):
    tenant_root = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    vendor = models.ForeignKey(Vendor, on_delete=models.PROTECT)
    status = models.CharField(max_length=24, default='DRAFT')
    ordered_at = models.DateField(null=True, blank=True)
    expected_at = models.DateField(null=True, blank=True)

class PurchaseOrderLine(models.Model):
    purchase_order = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name='lines')
    part = models.ForeignKey(Part, on_delete=models.PROTECT)
    quantity = models.DecimalField(max_digits=12, decimal_places=2)
    unit_cost_estimate = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    special_order_for_work_order = models.ForeignKey('work_orders.WorkOrder', null=True, blank=True, on_delete=models.SET_NULL)

class ReceivingReceipt(models.Model):
    tenant_root = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    purchase_order = models.ForeignKey(PurchaseOrder, null=True, blank=True, on_delete=models.SET_NULL)
    received_at = models.DateTimeField(default=timezone.now)
    packing_slip_number = models.CharField(max_length=80, blank=True)
    status = models.CharField(max_length=16, default='RECEIVED')

class ReceivingReceiptLine(models.Model):
    receipt = models.ForeignKey(ReceivingReceipt, on_delete=models.CASCADE, related_name='lines')
    purchase_order_line = models.ForeignKey(PurchaseOrderLine, null=True, blank=True, on_delete=models.SET_NULL)
    part = models.ForeignKey(Part, on_delete=models.PROTECT)
    quantity_received = models.DecimalField(max_digits=12, decimal_places=2)
    received_to_location = models.ForeignKey(InventoryLocation, on_delete=models.PROTECT)

class VendorBill(models.Model):
    tenant_root = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    vendor = models.ForeignKey(Vendor, on_delete=models.PROTECT)
    invoice_number = models.CharField(max_length=80)
    bill_date = models.DateField()
    status = models.CharField(max_length=16, default='ISSUED')

class VendorBillLine(models.Model):
    vendor_bill = models.ForeignKey(VendorBill, on_delete=models.CASCADE, related_name='lines')
    receipt_line = models.ForeignKey(ReceivingReceiptLine, null=True, blank=True, on_delete=models.SET_NULL)
    part = models.ForeignKey(Part, on_delete=models.PROTECT)
    quantity = models.DecimalField(max_digits=12, decimal_places=2)
    unit_cost = models.DecimalField(max_digits=12, decimal_places=2)

class SpecialOrderPartRequest(models.Model):
    tenant_root = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    work_order = models.ForeignKey('work_orders.WorkOrder', on_delete=models.CASCADE)
    part = models.ForeignKey(Part, on_delete=models.PROTECT)
    quantity = models.DecimalField(max_digits=12, decimal_places=2)
    preferred_vendor = models.ForeignKey(Vendor, null=True, blank=True, on_delete=models.SET_NULL)
    status = models.CharField(max_length=16, default='REQUESTED')
    purchase_order_line = models.ForeignKey(PurchaseOrderLine, null=True, blank=True, on_delete=models.SET_NULL)

class CoreLedgerEvent(models.Model):
    tenant_root = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    party_type = models.CharField(max_length=16)  # CUSTOMER or VENDOR
    party_id = models.CharField(max_length=64)    # customer_account_id or vendor_id (string to avoid cross-app circulars in stub)

    part = models.ForeignKey(Part, on_delete=models.PROTECT)
    qty = models.DecimalField(max_digits=12, decimal_places=2)
    event_type = models.CharField(max_length=24)
    occurred_at = models.DateTimeField(default=timezone.now)
