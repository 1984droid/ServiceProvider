# Services pseudocode (inventory)

## receive_parts(receipt, lines)
- validate tenant
- for each line:
  - create InventoryTransaction(RECEIVE, to_location, qty, unit_cost optional, source=Receipt)
  - update InventoryStock on_hand
  - if line is special order for WO:
      create InventoryReservation for that WO

## issue_part_to_work_order(work_order_item)
- validate stock availability unless override
- (optional) create/adjust reservation
- InventoryTransaction(ISSUE, from_location, qty, source=WorkOrder)
- update InventoryStock on_hand
- if part.is_rebuildable and core_charge_amount:
    create CoreLedgerEvent(CUSTOMER, CORE_CHARGED) linked to invoice line later

## reconcile_cycle_count(session)
- for each count line:
  delta = counted - system
  if delta > 0: create RECEIVE COUNT_ADJUSTMENT
  if delta < 0: create ISSUE COUNT_ADJUSTMENT
- update stock cache
- store variance report + approvals

## generate_reorder_suggestions(tenant)
- compute demand per (part, location)
- compute suggested min/max and order qty
- create ReorderSuggestion rows

## handle_customer_core_return(customer, part, qty)
- CoreLedgerEvent(CORE_RETURNED)
- create CreditMemo in financial system (if deposit refundable)
- CoreLedgerEvent(CORE_CREDIT_ISSUED) when credit issued
