# 09 Core Charges + Rebuildables (Gold Standard)

## Reality
Rebuildable/remanufactured parts create *core obligations*:
- Customers: owe you a core back (or forfeit deposit)
- Vendors: you owe vendors cores back (or pay core charge)

This is NOT just a price field; it is a balance and a lifecycle.

## Part configuration
Part fields:
- is_rebuildable (bool)
- core_part_id (optional: what core is expected)
- core_charge_amount (money)
- core_due_days (default 30)

## Core ledger events
CoreLedgerEvent:
- party_type: CUSTOMER or VENDOR
- party_id
- part_id (reman part)
- qty (how many cores)
- event_type:
  - CORE_CHARGED (obligation created)
  - CORE_RETURNED (physical return recorded)
  - CORE_CREDIT_ISSUED (credit memo / vendor credit issued)
  - CORE_WRITEOFF (core not returned; obligation closed as forfeited)

Balances computed:
- open_core_qty = charged - returned - writeoff (per party+part)

## Customer core flow
1) Part sold/issued -> core deposit line on invoice (or separate core line)
2) CoreLedgerEvent(CUSTOMER, CORE_CHARGED)
3) Customer returns core -> CoreLedgerEvent(CORE_RETURNED)
4) Issue CreditMemo/refund -> CoreLedgerEvent(CORE_CREDIT_ISSUED)

## Vendor core flow
1) Receive reman part; vendor bill may include core charge
2) Create CoreLedgerEvent(VENDOR, CORE_CHARGED)
3) Ship core back (CORE_RETURNED)
4) Vendor issues VendorCredit -> CORE_CREDIT_ISSUED

## Why this is gold standard
- you can always answer: "who owes cores, how many, and how old?"
- integrates directly with AR/AP credits and QBO sync
