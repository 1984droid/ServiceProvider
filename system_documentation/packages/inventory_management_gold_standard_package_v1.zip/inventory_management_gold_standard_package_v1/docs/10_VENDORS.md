# 10 Vendors (Foundational for purchasing + cores)

## Vendor model (minimum)
- name
- contacts
- terms
- default lead time
- preferred shipping method
- qbo mapping (via QBOMapping)

## Vendor performance metrics (later)
- lead time accuracy
- fill rate
- returns rate
