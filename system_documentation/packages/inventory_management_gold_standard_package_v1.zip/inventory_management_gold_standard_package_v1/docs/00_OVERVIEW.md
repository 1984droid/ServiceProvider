# 00 Overview

## Goals
Deliver a parts system that feels enterprise-grade but stays practical for repair shops:
- fast part lookup and issuing to work orders and counter sales
- accurate on-hand by location (warehouse, truck, bin)
- clean purchasing + receiving workflow
- audits: who adjusted inventory, why, and against which document
- core charges: track obligations (customer and vendor) and clear them with returns/credits

## Non-goals (v1)
- Full WMS (wave picking, RF routes)
- Full manufacturing / rebuild BOM costing (we support rebuildables + cores, not full production planning)
- Advanced forecasting ML (we start with deterministic heuristics)

## Definitions
- Part: catalog item with SKU, noun classification, costing rules, optional core/deposit configuration
- Location: physical stock container (warehouse, truck, bin, cage). Locations can be hierarchical.
- Stock: computed quantity per (part, location): on_hand, reserved, available
- Transaction: append-only inventory movement event (receive, issue, transfer, adjust)
- Special Order: purchase + reserve stock specifically for a work order
- Core: rebuildable core deposit obligations tracked as a ledger

## Tenant stance
Each tenant has:
- its own parts catalog (optionally shared templates later)
- its own inventory locations and quantities
- its own vendors and purchasing documents
- its own QBO connection and sync mappings
