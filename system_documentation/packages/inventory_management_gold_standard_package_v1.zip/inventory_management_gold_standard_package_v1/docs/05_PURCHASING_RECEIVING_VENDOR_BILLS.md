# 05 Purchasing + Receiving + Vendor Bills

## Workflow
1) ReorderSuggestion or SpecialOrderPartRequest creates PurchaseOrder
2) Vendor ships parts
3) ReceivingReceipt records what arrived (partial receipts allowed)
4) InventoryTransaction(RECEIVE) increases on-hand in receiving location
5) VendorBill records invoice and unit costs; links to ReceiptLines
6) PartReceiptCost captures final unit costs (for valuation and margin analysis)

## Why link receipt to vendor invoice?
- audit: trace where cost came from
- supports price updates and margin reporting
- supports warranty and vendor return workflows

## Returns to Vendor (RTV)
- Create RTV document (optional)
- InventoryTransaction(RETURN_TO_VENDOR) moves parts out of stock
- VendorCredit reduces AP (sync to QBO)
