# 04 Work Orders + POS Integration (How inventory moves)

## A) Work Order parts issue
When a mechanic adds a PART line:
1) Select part_id, qty, and issue_location_id (defaults to tech truck)
2) Reserve qty (optional but recommended) -> InventoryReservation
3) When issued/installed:
   - create InventoryTransaction(type=ISSUE, from_location=issue_location)
   - decrement on_hand_qty
4) If part has core charge:
   - create CoreLedgerEvent(party=CUSTOMER, CORE_CHARGED) OR link to invoice line (preferred)

## B) Counter sales (POS)
SalesTicketLine with part_id:
- reserve (optional) until paid
- on ticket paid:
  - InventoryTransaction(type=ISSUE) from POS location (counter stock bin)
- generate invoice/sales receipt in financial system

## C) Returns
Customer returns part:
- InventoryTransaction(type=RECEIVE) to a returns bin (or back to stock after inspection)
- If core return:
  - CoreLedgerEvent(CORE_RETURNED) then CreditMemo/Refund if applicable

## D) Negative inventory policy
Avoid negative inventory by default.
If you must allow it:
- allow ISSUE that drives on_hand negative with permission
- record exception and require later receiving to reconcile.
