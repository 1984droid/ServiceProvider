# 02 Roadmap (Implementation Plan)

This is ordered to get you to value quickly while keeping correctness.

---

## Phase I1 — Parts Catalog + Noun Classification (Foundation)
### Build
- Part model with:
  - SKU, barcode, description, uom, noun_item_id
  - is_stocked, is_serialized (optional), reorderable
  - costing defaults
  - core config (optional)
- Part pricing defaults (unit_cost_default, unit_price_default)

### Acceptance
- Parts dept can create a Part and classify it with noun_item_id
- Search parts by SKU/barcode/description/noun category

---

## Phase I2 — Locations + Stock + Inventory Transactions
### Build
- InventoryLocation hierarchy (warehouse/truck/bin)
- InventoryTransaction append-only
- Stock cache table updated transactionally
- Transfers between locations
- Basic adjustments

### Acceptance
- On-hand by location is accurate
- Transfers between warehouse and truck work
- Every move is auditable

---

## Phase I3 — Counts / Cycle Count
### Build
- CycleCountSession + CountLines
- Reconciliation produces InventoryTransaction adjustments
- Variance reports and approvals (optional)

### Acceptance
- You can count a truck or a bin, reconcile, and see variance

---

## Phase I4 — Work Order Consumption + Special Orders
### Build
- WorkOrderItem(part_id, issue_location_id, qty)
- Reservation:
  - reserve parts for a WO
  - issue parts to WO (decrement on_hand)
- SpecialOrderPartRequest linked to WO:
  - converts into PurchaseOrderLine
  - auto-reserves received parts for that WO

### Acceptance
- Mechanics can pick/issue parts from a truck location
- Special-order parts are not accidentally sold elsewhere

---

## Phase I5 — Vendors + Purchasing + Receiving + Vendor Bills
### Build
- Vendor model
- PurchaseOrder + lines
- ReceivingReceipt + lines (can be partial)
- VendorBill + lines linked to receipt and PO lines
- Traceability: PartReceiptCost records (unit cost from invoice)

### Acceptance
- You can order, receive, and bill parts and tie receipt to a vendor invoice number

---

## Phase I6 — Reorder Planning + Auto Min/Max
### Build
- ReorderPolicy per (part, location): min, max, lead time, review period
- Demand calculation from:
  - WorkOrder issues
  - POS sales
- Auto-suggest min/max based on history (heuristics in docs)
- ReorderSuggestions -> create PO

### Acceptance
- System can recommend reorder quantities and min/max updates

---

## Phase I7 — Core Charges (Customer + Vendor)
### Build
- CoreLedgerEvent (party=customer/vendor)
- CoreObligation balances + aging
- Customer core returns -> CreditMemo workflow
- Vendor core returns -> VendorCredit workflow

### Acceptance
- You can see who owes cores and how many
- You can clear obligations correctly and produce credits

---

## Phase I8 — QBO Sync (per tenant)
### Build
- QBOMapping for Vendor, Item, PO/Bill, VendorCredit, Invoice/SalesReceipt, CreditMemo
- Outbox event processing and idempotency
- Sync logs

### Acceptance
- Issued invoices and vendor bills sync cleanly to QBO without duplicates
