# 13 Migrations + Backfill

## Migration order
1) Vendor + Part
2) InventoryLocation + InventoryTransaction + InventoryStock
3) Purchasing docs (PO, Receipt, VendorBill)
4) Reservation + SpecialOrderPartRequest
5) Cycle counts
6) Core ledger

## Backfill stance
- No backfill required initially
- Inventory begins at zero until you receive or load starting inventory
- Provide an "Initial Inventory Load" tool that creates ADJUSTMENT transactions with reason=INITIAL_LOAD

## Safety
- Keep transactions append-only
- Use db constraints and transactional updates to keep stock cache consistent
