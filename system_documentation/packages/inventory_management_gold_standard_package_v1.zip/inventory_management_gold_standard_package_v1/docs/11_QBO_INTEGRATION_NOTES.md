# 11 Financial + QuickBooks Integration Notes

## Financial system integration points
- VendorBill creation for received parts (AP)
- Invoice/SalesReceipt for parts sold (AR)
- CreditMemo for customer core returns
- VendorCredit for vendor core credits
- Optional: PurchaseOrder push to QBO

## Recommended sync scope (v1)
Push to QBO:
- Vendors
- Items (Parts as QBO Items; services handled separately)
- Bills (VendorBill)
- VendorCredits
- Invoices/SalesReceipts
- CreditMemos
- Payments (from financial package)

Do NOT try to sync bin-level stock. Keep operational locations internal.

## Costing
- Your system stores unit cost per receipt/bill line.
- QBO may maintain its own inventory valuation; treat QBO as accounting truth.
- Your app uses costs for margin analysis and internal reporting.
