# 03 Data Models (Proposed)

## Part
- tenant_id
- sku (unique per tenant)
- barcode_upc (optional)
- noun_item_id (required)
- description (short)
- base_uom (each, etc.)
- purchase_uom (case, each) + conversion_factor (optional)
- is_stocked (bool)
- is_serialized (bool)
- default_unit_cost
- default_unit_price
- core_config (see Core section)

## InventoryLocation
- tenant_id
- name
- location_type: WAREHOUSE, TRUCK, BIN, CAGE, SITE, OTHER
- parent_location_id (nullable for hierarchy)
- code (unique per tenant, searchable)
- assigned_to_asset_id (nullable)  # for service truck inventory tied to a vehicle asset
- is_active

## InventoryStock (cache)
- tenant_id
- part_id
- location_id
- on_hand_qty
- reserved_qty
- available_qty (computed)
- last_updated_at
Indexes: (tenant, part), (tenant, location), (tenant, part, location)

## InventoryTransaction (ledger)
Append-only:
- tenant_id
- occurred_at
- part_id
- quantity (positive number)
- from_location_id nullable
- to_location_id nullable
- transaction_type enum:
  RECEIVE, ISSUE, TRANSFER, ADJUSTMENT, COUNT_ADJUSTMENT, RETURN_TO_VENDOR, SCRAP, CORE_RETURN
- source_type/source_id (PO, Receipt, VendorBill, WorkOrder, SalesTicket, Manual)
- unit_cost (optional, for valuation)
- notes (short)
- created_by

## Purchasing
Vendor
- tenant_id
- name, contact fields
- terms (net30)
- qbo mapping fields (handled by QBOMapping)

PurchaseOrder + PurchaseOrderLine
ReceivingReceipt + ReceiptLine (links to PO lines)
VendorBill + BillLine (links to receipt and PO lines)

PartReceiptCost (optional but recommended)
- receipt_line_id
- part_id
- unit_cost
- vendor_invoice_number
- received_at

## Reservation / Allocation
InventoryReservation
- tenant_id
- part_id
- location_id
- reserved_qty
- reserved_for_type: WORK_ORDER, SALES_TICKET
- reserved_for_id
- created_at, status

SpecialOrderPartRequest
- work_order_id
- part_id
- quantity
- vendor_id preferred
- status: REQUESTED, ORDERED, RECEIVED, ISSUED, CANCELLED
- linked_purchase_order_line_id

## Cycle counts
CycleCountSession
- location_id (or parent location)
- status
- started_at, closed_at
CycleCountLine
- part_id
- counted_qty
- system_qty_at_start
Reconcile -> COUNT_ADJUSTMENT transaction(s)

## Core tracking (ledger)
CoreLedgerEvent
- tenant_id
- party_type: CUSTOMER, VENDOR
- party_id (customer_account_id or vendor_id)
- part_id (the reman part) + core_part_id (optional)
- qty
- event_type: CORE_CHARGED, CORE_RETURNED, CORE_CREDIT_ISSUED, CORE_WRITEOFF
- related_invoice_line_id / vendor_bill_line_id / work_order_item_id
- occurred_at
Balances derived by aggregation per party+part.
