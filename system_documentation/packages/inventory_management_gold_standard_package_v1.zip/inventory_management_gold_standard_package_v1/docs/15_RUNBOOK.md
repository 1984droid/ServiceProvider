# 15 Runbook (Ops)

## Common issues
- Negative inventory: investigate missing receipts or double issues
- Variances in counts: review adjustment reasons and approvals
- Special order consumed by wrong job: verify reservation enforcement

## Monitoring
- daily: inventory adjustment volume
- weekly: top stockouts
- monthly: core balances aging report (customer + vendor)

## Cutover
- load starting inventory by location via INITIAL_LOAD transactions
- validate stock snapshot reports per location
