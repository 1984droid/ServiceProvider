# 12 API Endpoints (Suggested)

## Parts catalog
- GET/POST /api/parts/
- GET/PATCH /api/parts/{id}/

## Locations
- GET/POST /api/inventory/locations/
- GET/PATCH /api/inventory/locations/{id}/
- GET /api/inventory/locations/{id}/stock/

## Inventory transactions
- POST /api/inventory/receive
- POST /api/inventory/issue
- POST /api/inventory/transfer
- POST /api/inventory/adjust

## Counts
- POST /api/inventory/cycle-count/start
- POST /api/inventory/cycle-count/{id}/submit
- POST /api/inventory/cycle-count/{id}/reconcile

## Purchasing
- GET/POST /api/vendors/
- GET/POST /api/purchase-orders/
- POST /api/purchase-orders/{id}/receive
- POST /api/vendor-bills/

## Special orders
- POST /api/work-orders/{id}/special-orders/request
- POST /api/special-orders/{id}/convert-to-po

## Core tracking
- GET /api/cores/customer-balances
- GET /api/cores/vendor-balances
- POST /api/cores/record-return
- POST /api/cores/issue-credit
