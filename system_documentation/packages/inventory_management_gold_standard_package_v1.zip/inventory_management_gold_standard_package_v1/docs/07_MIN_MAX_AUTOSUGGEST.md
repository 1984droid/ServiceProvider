# 07 Min/Max + Auto-suggest (Sales/Usage History)

## Data sources for demand
- WorkOrderItem PART issues (preferred: actual issues, not merely invoiced)
- POS SalesTicket issues
Optionally:
- invoice line sales if you allow selling without inventory decrement (not recommended)

## Per (part, location) ReorderPolicy
Fields:
- min_qty, max_qty (manual)
- lead_time_days (manual)
- review_period_days (manual; weekly/monthly)
- safety_stock_days (manual or default)
- auto_min_max_enabled (bool)
- last_computed_at

## Suggested algorithm (deterministic, explainable)
Compute avg daily demand:
- demand = total issued qty over last N days / N
Pick N=90 by default (configurable), with decay weights optional.

Compute:
- reorder_point = demand * lead_time_days + (demand * safety_stock_days)
- max_qty = reorder_point + demand * review_period_days

Round rules:
- round up to vendor pack size (purchase_uom conversion)
- enforce min >= 0 and max >= min

## Output
- ReorderSuggestion rows:
  - part_id, location_id
  - suggested_order_qty = max_qty - on_hand - on_order + reserved buffer
  - suggested_min_qty, suggested_max_qty
- Allow reviewer to accept suggested policy updates (audit logged)

## Why this is gold standard
- it is explainable to humans (no black box)
- it improves automatically as data grows
