# 06 Counts / Cycle Counts (Exceptional, not annoying)

## Design goals
- fast counting by bin/truck
- reliable reconciliation
- approvals for large variances
- full audit trail

## CycleCountSession
- choose a location scope (warehouse aisle, truck, bin)
- snapshot system quantities at start (system_qty_at_start)
- record counted quantities per part
- reconcile:
  - for each part: delta = counted - system
  - create COUNT_ADJUSTMENT InventoryTransaction with delta sign:
    - if counted > system -> RECEIVE to location
    - if counted < system -> ISSUE from location
- store variance report

## Controls (recommended)
- require supervisor approval if variance value exceeds threshold
- require reason codes for adjustments: damage, theft, mis-pick, data fix
