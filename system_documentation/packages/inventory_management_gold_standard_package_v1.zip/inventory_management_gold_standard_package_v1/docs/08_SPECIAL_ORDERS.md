# 08 Special Orders (Directly tied to Work Orders)

## Problem
Special-order parts must not be accidentally consumed by other jobs.

## Model
SpecialOrderPartRequest:
- work_order_id
- part_id + qty
- preferred_vendor_id (optional)
- status state machine
- purchase_order_line_id (link)

## Workflow
1) Mechanic/service writer flags part line as special order
2) System creates SpecialOrderPartRequest
3) Buyer converts requests into a PurchaseOrder (batch)
4) On receiving:
   - receive into SpecialOrder Staging location (or direct to WO reserved)
   - automatically create InventoryReservation for the WO
5) When issued to WO:
   - InventoryTransaction(ISSUE) from staging
   - mark request ISSUED

## Customer communication
Special orders should expose:
- ordered_at, promised_date, received_at
This becomes a service writer dashboard.
