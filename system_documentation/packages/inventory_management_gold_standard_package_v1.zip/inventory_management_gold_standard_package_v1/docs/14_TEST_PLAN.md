# 14 Test Plan (Correctness + Audit)

## Inventory ledger
- receive increases on_hand
- issue decreases on_hand
- transfer moves between locations
- idempotency keys prevent duplicate receipts/issues

## Reservation
- reserved reduces available but not on_hand
- issuing reserved qty clears reservation

## Cycle count reconcile
- creates correct COUNT_ADJUSTMENT transactions
- variance approvals enforced when threshold exceeded

## Purchasing
- PO -> receipt -> bill links consistent
- unit cost applied correctly to receipt cost records

## Core ledger
- balances computed correctly for customer and vendor
- credit issued clears obligations

## QBO sync hooks (smoke tests)
- bill created triggers outbox event
- invoice created triggers outbox event
- mapping table prevents duplicate creates
