# 01 Architecture Decisions (Gold Standard)

## A) Event-sourced inventory ledger
Inventory quantities are derived from append-only InventoryTransaction rows.
We store a cached Stock table for speed, but the ledger is the truth.

Benefits:
- auditability (who moved what, when, why)
- replay and correction
- traceability to documents (PO, receiving, vendor bill, WO, POS ticket)

## B) Locations are first-class and hierarchical
Locations support:
- warehouse -> aisle -> bin
- service truck -> shelf -> bin
- job site -> gang box

You can filter stock by any parent location.

## C) Reservation is required for special orders and high discipline shops
We track:
- reserved_qty (allocated to a WO or POS ticket)
- available_qty = on_hand - reserved

This prevents double-selling.

## D) Purchasing + receiving + vendor bill are separate concepts
- PurchaseOrder = what you ordered
- ReceivingReceipt (GRN) = what physically arrived
- VendorBill = what you were invoiced for (AP)

They are related but not identical; real life needs the separation.

## E) Core charges are a ledger, not a boolean
Cores are obligations and clearances:
- customer owes core return: obligation created on sale/issue
- vendor core owed: obligation created on purchase receipt or vendor bill (depending on vendor terms)
- cleared on return shipment / credit memo

## F) QBO integration
Sync financial documents, not your operational bin locations:
- push Vendor, Item, PO/Bill, Invoice/SalesReceipt, CreditMemo/VendorCredit (as desired)
Inventory quantities by bin/truck generally stay in your system.
