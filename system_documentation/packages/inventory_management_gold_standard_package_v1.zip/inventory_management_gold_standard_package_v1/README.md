# Inventory & Parts Management — Gold Standard Package (v1)

Generated: 2026-02-08

This package is an **agent-ready implementation kit** to build an exceptional, multi-tenant parts + inventory system that supports:
- Per-tenant parts catalog with noun-based classification
- Multi-location inventory (warehouse, bins, trucks, job boxes)
- Stock counts / cycle counts with audit-grade adjustments
- Min/Max + reorder planning (including auto-suggested min/max from sales/usage history)
- Purchasing (vendors, purchase orders, receiving, vendor bills) with traceability to invoice/packing slip
- Special-order parts tied directly to a Work Order
- Core charge + rebuildable part tracking:
  - cores customers owe back
  - cores you owe vendors back
  - credits when cores are returned

It integrates with:
- Work Orders Gold Standard package (WorkOrderItem financials + ledger)
- Financial System (QBO-ready) package (Invoices/Payments + QBO sync)
- Leasing Compliance package (optional: cost summaries; not required)

Key principle:
**Inventory is managed operationally in your platform, while QuickBooks remains the accounting system-of-record.**
We sync financial documents (bills/invoices/credits) to QBO and keep multi-location accuracy in our app.

## Contents
- docs/*.md (design + roadmap + workflows)
- schemas/*.schema.json (validation contracts)
- stubs/*.py / *.md (Django model skeleton + service pseudocode)
