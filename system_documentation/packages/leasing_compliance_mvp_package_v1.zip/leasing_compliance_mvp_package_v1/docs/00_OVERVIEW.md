# 00 Overview

## Goal
Enable a *leasing company tenant* to monitor that leased assets are being maintained and inspected to standard, even when:
- the customer is a separate tenant
- the repair shop is a separate tenant
- inspections/maintenance/work orders are performed in the repair shop tenant

## Product Outcome (MVP)
Leasing tenant can:
1) See all assets that are leased from them **where sharing is granted**
2) See compliance status per asset:
   - COMPLIANT / DUE_SOON / OVERDUE / OUT_OF_SERVICE / UNKNOWN
3) Drill into *why* (missing inspection, overdue maintenance, evidence missing)
4) View inspection details and evidence ONLY if contract allows
5) Receive alerts for due soon / overdue / out-of-service

## Non-goals (MVP)
- No lease billing integration
- No leasing edits to work orders/inspections
- No incentives scoring (post-MVP)

## Golden Constraints
- Explicit cross-tenant access via SharingContract (opt-in, revocable)
- Default deny. If no grant -> show UNKNOWN
- Every access is logged (SharingAccessLog)
