# 05 Notifications (MVP)

Alert types:
- DUE_SOON: next_action_date within due_soon_days
- OVERDUE: next_action_date past due + grace_period_days
- OUT_OF_SERVICE: unsafe defect or flag

Delivery:
- email (initial)
- in-app notifications (optional)
- defer webhooks to post-MVP

Rules:
- de-duplicate alerts (don't spam daily)
- include explainable reasons and deep links

Scheduling:
- nightly after compliance recompute
- plus immediate alert when inspection finalizes to OUT_OF_SERVICE
