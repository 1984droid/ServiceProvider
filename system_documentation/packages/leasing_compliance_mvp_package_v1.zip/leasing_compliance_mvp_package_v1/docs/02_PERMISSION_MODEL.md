# 02 Permission Model (Cross-Tenant)

## 1) Philosophy
- Leasing visibility is **always explicit** via SharingContract.
- Default deny.
- Customer can revoke immediately.
- Leasing tenant gets read-only access for monitoring.

## 2) Asset visibility computation
Given user from leasing tenant L:
1) Find active SharingContracts where grantee == L and revoked_at is null and effective_date <= today and (expires_at is null or expires_at > now)
2) For each contract, compute eligible assets with SharedAssetScope rules
3) Union those asset IDs
4) Apply per-contract permission filtering downstream (details/evidence may differ by contract)

## 3) SharedAssetScope (JSON)
Supported scope rules (MVP):
- {"type":"all_leased_from_grantee"}:
    Assets where asset.leased_by_tenant == grantee_tenant
- {"type":"asset_list","asset_ids":[...]}
- {"type":"organization","organization_id": "..."}:
    Assets where asset.leased_by_organization == org_id
- {"type":"tags","tags":[...]}:
    Assets with matching tags

Important: scope rules should be composable: OR across scopes in a contract.

## 4) Permission matrix
permissions JSON should be a stable schema:
- asset_profile: true/false
- maintenance_history: none|summary|full
- inspection_results: none|summary|full
- evidence_attachments: true/false
- work_orders: none|summary|full
- provider_identity: true/false
- export_allowed: true/false

## 5) Where enforcement happens
Enforce in:
- queryset filtering utilities (single source of truth)
- serializer field-level filtering (based on permissions)
- view-level guards (for evidence endpoints)
- ALWAYS log via SharingAccessLog

## 6) Avoiding leakage
- Never allow leasing tenant to query by raw primary keys without passing through visibility filtering.
- Use "object permission" checks in detail endpoints.
- Unit tests MUST include negative cases for every endpoint.
