# 01 Data Models

All models are additive and sit beside existing assets/inspections/maintenance models.

## 1) SharingContract (critical)
Represents an explicit data-sharing agreement:
- grantor = customer tenant (or repair shop tenant)
- grantee = leasing tenant
- scope rules define which assets are visible
- permissions define what data types are visible

### Required fields
- grantor_tenant_id
- grantee_tenant_id
- scope (JSON)
- permissions (JSON)
- effective_date (date)  <-- controls historical lookback start
- expires_at (datetime, nullable)
- revoked_at (datetime, nullable)

## 2) SharingAccessLog (append-only)
Log every access:
- sharing_contract_id
- accessed_by_user_id
- accessed_at
- resource_type (asset|inspection|work_order|evidence|export)
- resource_id
- action (view|export)

## 3) LeasePolicy
Defines compliance requirements:
- tenant_root_id (leasing tenant)
- name, description
- required_inspection_programs (list of program keys or wildcard patterns)
- required_maintenance_programs (list of program keys or wildcard patterns)
- thresholds (due_soon_days, grace_period_days, overdue thresholds)
- evidence requirements (photos/test_data/signatures)
- provider requirements (verified providers only)
- standards requirements (minimum standards pack revision)

## 4) PolicyAssignment
Links a policy to a set of assets:
- policy_id
- target_type + target_id (one-of):
  - asset
  - leased_by_organization (customer org)
  - asset_subtype_key
  - tag
  - global_for_leasing_tenant

Start MVP with:
- asset_subtype_key + leased_by_organization + asset overrides
Add advanced scopes later.

## 5) AssetComplianceSnapshot
Materialized view:
- asset_id
- leasing_tenant_id
- policy_id
- computed_at
- compliance_status (COMPLIANT|DUE_SOON|OVERDUE|OUT_OF_SERVICE|UNKNOWN)
- next_action_date (min(next_inspection_due, next_maintenance_due))
- inspection fields (last/next due)
- maintenance fields (last/next due)
- evidence_ok + missing_evidence JSON
- provider_verified + standards_version_met
- compliance_issues JSON (explainability)

Index heavily:
- (leasing_tenant_id, compliance_status)
- (asset_id, policy_id)
- (leasing_tenant_id, next_action_date)
