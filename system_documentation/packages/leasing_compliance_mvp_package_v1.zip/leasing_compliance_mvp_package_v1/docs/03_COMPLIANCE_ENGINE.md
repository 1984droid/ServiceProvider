# 03 Compliance Computation Engine

## 1) Inputs
- LeasePolicy requirements
- PolicyAssignment targets
- Asset state (subtype, capabilities, meters)
- InspectionRun (finalized) + defects + evidence presence
- Maintenance events / Work orders completion markers
- Provider verification flags
- Standards pack version metadata captured at inspection time

## 2) Outputs
AssetComplianceSnapshot rows per (asset, policy, leasing_tenant)

## 3) Core function: compute_asset_compliance(asset, policy)
Pseudo-steps:
1) Determine required programs:
   - expand wildcard patterns (ex: "ip.ansi_a92_2_*") against program table
2) For each required inspection program:
   - find last finalized InspectionRun for that asset+program
   - compute next due date/meter from program schedule
   - evaluate due_soon / overdue with grace_period_days
   - evidence checks: photos/test_data/signature requirements
3) For each required maintenance program:
   - find last completion event
   - compute next due date/meter
4) Determine OUT_OF_SERVICE:
   - if latest inspection has UNSAFE defects not resolved
   - OR asset.out_of_service flag set
5) Compute overall status:
   - OUT_OF_SERVICE > OVERDUE > DUE_SOON > COMPLIANT
   - UNKNOWN if cannot evaluate (no sharing, no history beyond effective_date, missing meters)
6) Build compliance_issues list:
   - each issue includes: kind, severity, program_key, due_date, overdue_by, missing_evidence keys

## 4) Performance strategy
- Nightly batch recompute for leasing tenant's visible assets
- On-change triggers:
  - inspection finalized
  - maintenance completed
  - meter reading updated
- Use DB indexes and select_related/prefetch_related for batch work
- Consider chunking by tenant and using task queue for parallelism

## 5) Explainability contract
Every snapshot must include reasons:
- compliance_status without reasons is unusable in practice.
