# 04 API Endpoints (MVP)

All endpoints must enforce SharingContract + log access.

## Leasing views
- GET /api/leasing/contracts/ (list active sharing contracts)
- GET /api/leasing/customers/ (derived from leased_by_organization in visible assets)
- GET /api/leasing/customers/{org_id}/assets/
- GET /api/leasing/assets/overdue/
- GET /api/leasing/assets/{asset_id}/compliance/
- GET /api/leasing/compliance-summary/

## Inspection detail (permissioned)
- GET /api/leasing/inspections/{inspection_run_id}/
- GET /api/leasing/inspections/{inspection_run_id}/defects/
- GET /api/leasing/evidence/{attachment_id}/  (only if evidence_attachments true)

## Optional exports (if export_allowed)
- POST /api/leasing/compliance-report/export (pdf/xlsx)

## Important response fields
Compliance endpoints should return:
- compliance_status
- next_action_date
- due_soon/overdue counts
- top compliance_issues
- last inspection summary (program key + date + result)
- last maintenance summary (program key + date)
