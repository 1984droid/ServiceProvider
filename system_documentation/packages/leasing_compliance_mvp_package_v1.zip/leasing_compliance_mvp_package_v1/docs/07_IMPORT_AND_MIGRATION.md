# 07 Import and Migration Strategy

## 1) Migrations
- Add new models:
  - SharingContract
  - SharingAccessLog
  - LeasePolicy
  - PolicyAssignment
  - AssetComplianceSnapshot
- Add optional fields:
  - Tenant.is_verified_provider, Tenant.verified_at, Tenant.certifications
  - InspectionRun.standards_pack_version (string)

## 2) Backfill & Defaults
- Create a default LeasePolicy per leasing tenant:
  - due_soon_days=30
  - grace_period_days=7
- Create a default PolicyAssignment:
  - apply to all assets leased_by_tenant = leasing tenant (if desired)
- Do NOT auto-create SharingContracts. Make it explicit.

## 3) Import tools
Create management commands:
- manage.py leasing_validate_config (validate JSON schemas)
- manage.py leasing_recompute_compliance --tenant=<id> [--all]
- manage.py leasing_send_alerts --tenant=<id>

## 4) Observability
- log job run durations
- record counts updated
- surface errors in admin dashboard
