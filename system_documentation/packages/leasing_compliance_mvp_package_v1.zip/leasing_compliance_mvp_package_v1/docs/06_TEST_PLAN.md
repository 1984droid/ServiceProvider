# 06 Test Plan (Security + Correctness)

## 1) SharingContract tests
- grantor cannot grant to unknown grantee
- revocation immediately blocks access
- expires_at blocks access
- effective_date blocks historical visibility before date

## 2) Scope rules tests
- all_leased_from_grantee matches leased_by_tenant correctly
- asset_list exact set
- organization scope returns correct assets
- tags scope returns correct assets
- union across multiple contracts works

## 3) Permission matrix tests
For each endpoint:
- deny when permission missing
- allow when granted
- field-level redaction works (summary vs full)

## 4) Compliance computation tests
- time-based due/overdue with grace period
- meter-based due/overdue
- missing meters -> UNKNOWN + reason
- unsafe defects -> OUT_OF_SERVICE
- evidence missing -> OVERDUE or NONCOMPLIANT (depending on policy) + reason
- standards version mismatch -> issue flagged

## 5) Performance tests
- recompute for 10k assets within acceptable time
- batch query count constraints (no N+1)
