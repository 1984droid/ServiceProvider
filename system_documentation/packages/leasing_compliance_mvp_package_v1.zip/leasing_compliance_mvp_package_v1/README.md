# Leasing Compliance Monitoring MVP Package (v1)

Generated: 2026-02-08

This package is an implementation roadmap + schema kit to build a **Leasing Compliance Monitoring** layer on top of your existing:
- multi-tenant model (tenant types include leasing_company)
- Asset leasing relationships (leased_by_tenant / leased_by_organization)
- inspections system with immutable audit trail + defects
- maintenance programs with time/meter schedules
- structured work orders (verb+noun+location)

Key principle: **read-only visibility + policy + computed compliance snapshots**.
Leasing tenants do NOT edit work orders/inspections.

## Files
- docs/00_OVERVIEW.md
- docs/01_DATA_MODELS.md
- docs/02_PERMISSION_MODEL.md
- docs/03_COMPLIANCE_ENGINE.md
- docs/04_API_ENDPOINTS.md
- docs/05_NOTIFICATIONS.md
- docs/06_TEST_PLAN.md
- docs/07_IMPORT_AND_MIGRATION.md
- schemas/*.json (permission + policy + snapshot schemas)
- stubs/django_models.py (model skeletons)
- stubs/api_openapi.yaml (starter OpenAPI)
- stubs/tasks_and_triggers.md (jobs + triggers outline)

## Intended Use
Give this to your coding agent as the **source of truth** for the implementation sequence and acceptance criteria.
