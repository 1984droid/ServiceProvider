# Django model skeletons (stubs)
# NOTE: adapt import paths to your project structure.

from django.db import models
from django.utils import timezone

class SharingContract(models.Model):
    grantor_tenant = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE, related_name='sharing_grants')
    grantee_tenant = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE, related_name='sharing_receipts')

    scope = models.JSONField(default=list)        # list of scope rule objects
    permissions = models.JSONField(default=dict)  # permissions schema

    effective_date = models.DateField(default=timezone.now)
    expires_at = models.DateTimeField(null=True, blank=True)
    revoked_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def is_active(self):
        now = timezone.now()
        if self.revoked_at:
            return False
        if self.expires_at and self.expires_at <= now:
            return False
        if self.effective_date and self.effective_date > now.date():
            return False
        return True

class SharingAccessLog(models.Model):
    sharing_contract = models.ForeignKey(SharingContract, on_delete=models.CASCADE)
    accessed_by_user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    accessed_at = models.DateTimeField(default=timezone.now)

    resource_type = models.CharField(max_length=32)
    resource_id = models.UUIDField()
    action = models.CharField(max_length=16, default='view')

class LeasePolicy(models.Model):
    tenant_root = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    name = models.CharField(max_length=120)
    description = models.TextField(blank=True)

    required_inspection_programs = models.JSONField(default=list)
    required_maintenance_programs = models.JSONField(default=list)

    due_soon_days = models.IntegerField(default=30)
    grace_period_days = models.IntegerField(default=7)
    overdue_threshold_days = models.IntegerField(default=0)
    overdue_threshold_miles = models.IntegerField(default=0)
    overdue_threshold_hours = models.IntegerField(default=0)

    require_photos = models.BooleanField(default=False)
    require_test_data = models.BooleanField(default=False)
    require_signatures = models.BooleanField(default=False)

    verified_providers_only = models.BooleanField(default=False)
    min_standards_version = models.CharField(max_length=50, blank=True)

    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class PolicyAssignment(models.Model):
    policy = models.ForeignKey(LeasePolicy, on_delete=models.CASCADE)
    target_type = models.CharField(max_length=32)  # 'asset'|'organization'|'subtype'|'tag'|'global'
    target_value = models.CharField(max_length=128) # uuid, org_id, subtype_key, tag, etc.
    created_at = models.DateTimeField(auto_now_add=True)

class AssetComplianceSnapshot(models.Model):
    asset = models.ForeignKey('assets.Asset', on_delete=models.CASCADE)
    leasing_tenant = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    policy = models.ForeignKey(LeasePolicy, on_delete=models.CASCADE)

    computed_at = models.DateTimeField(default=timezone.now)
    compliance_status = models.CharField(max_length=20)
    next_action_date = models.DateField(null=True, blank=True)

    evidence_ok = models.BooleanField(default=True)
    missing_evidence = models.JSONField(default=list)

    provider_verified = models.BooleanField(default=False)
    standards_version_met = models.BooleanField(default=True)

    compliance_issues = models.JSONField(default=list)

    class Meta:
        indexes = [
            models.Index(fields=['leasing_tenant','compliance_status']),
            models.Index(fields=['leasing_tenant','next_action_date']),
            models.Index(fields=['asset','policy']),
        ]
