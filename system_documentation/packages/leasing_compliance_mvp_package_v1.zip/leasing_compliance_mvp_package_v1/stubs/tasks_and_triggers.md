# Tasks and Triggers

## Nightly tasks (batch)
- leasing_recompute_compliance:
  For each leasing tenant:
    - find visible assets (via SharingContracts)
    - find relevant policies (assignments)
    - recompute snapshots in batches (chunk size configurable)

- leasing_send_alerts:
  Use AssetComplianceSnapshot to find state transitions:
    - COMPLIANT -> DUE_SOON
    - DUE_SOON -> OVERDUE
    - * -> OUT_OF_SERVICE
  De-dupe per asset+issue type.

## On-change triggers (event-driven)
Trigger recompute for a single asset when:
- inspection finalized (InspectionRun finalized_at set)
- maintenance completed (work order closed or maintenance record saved)
- meter reading updated

Implementation options:
- Celery task queue
- Django signal handlers
- explicit call in service layer (preferred for control)
