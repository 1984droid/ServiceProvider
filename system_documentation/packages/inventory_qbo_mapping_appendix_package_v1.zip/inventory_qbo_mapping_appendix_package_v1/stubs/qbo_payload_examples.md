# QBO Payload Examples (Conceptual)

These are conceptual shapes; use Intuit's API Explorer for exact fields.

## 1) QBO Item for a Part (financial-only)
- Name: "SKU - Description"
- Type: NonInventory
- IncomeAccountRef: parts income account

## 2) QBO Invoice with reman + core deposit
Line A: Reman part item, qty=1
Line B: Core deposit item, qty=1

## 3) QBO CreditMemo for core return
- references same Core deposit item with negative amount (or credit memo line)

## 4) VendorCredit for vendor core credit
- VendorCredit with line referencing core deposit/charge item or expense account

Idempotency:
- store returned Id and SyncToken after each create/update
