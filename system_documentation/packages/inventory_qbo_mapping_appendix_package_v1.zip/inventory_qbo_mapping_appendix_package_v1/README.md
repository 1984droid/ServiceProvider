# Inventory ↔ QuickBooks Online Mapping Appendix — v1

Generated: 2026-02-08

This appendix is meant to be used *alongside*:
- Inventory Management Gold Standard Package v1
- Financial System (QBO-ready) Package v1

Purpose:
- Provide a clear, configurable mapping strategy to QuickBooks Online (QBO) for:
  - Parts/Items
  - Vendor bills & vendor credits
  - Invoices & sales receipts
  - Credit memos (including customer core refunds)
  - Optional purchase orders (often deferred)
- Avoid common sync traps (duplicates, mismatched inventory counts, wrong item types)

Key policy decision:
- Default to **Financial-only QBO sync** for inventory quantities:
  - Your system tracks multi-location stock.
  - QBO receives the financial documents (bills/invoices/credits/payments).
  - QBO does NOT receive bin/truck stock quantities.

If a tenant later requires QBO quantity-on-hand tracking, that becomes a separate opt-in mode.

Contents:
- docs/00_QBO_SYNC_MODES.md
- docs/01_ENTITY_MAPPING.md
- docs/02_ITEM_TYPES_POLICY.md
- docs/03_CORE_DEPOSIT_PATTERN.md
- docs/04_PURCHASE_ORDERS_POLICY.md
- docs/05_IDEMPOTENCY_AND_MAPPING_TABLES.md
- docs/06_ACCOUNT_MAPPING_GUIDE.md
- schemas/*.schema.json
- stubs/qbo_payload_examples.md
