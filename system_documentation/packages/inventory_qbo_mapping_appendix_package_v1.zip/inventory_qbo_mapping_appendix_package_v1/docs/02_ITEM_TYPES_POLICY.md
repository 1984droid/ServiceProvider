# 02 Item Types Policy (Parts, Services, Core Deposits)

QuickBooks Online item types influence how QBO tracks quantity and accounting.

## Recommended v1 default
- Parts: create as NON-INVENTORY in QBO (financial-only mode)
- Labor/services: create as SERVICE in QBO
- Core deposits: create as NON-INVENTORY item in QBO

## Why not default to inventory items in QBO?
Because your system tracks multi-location stock. QBO inventory is not bin/truck aware in your design.

## Bundle items
Avoid QBO bundle items initially; keep your invoice lines explicit.

## Tenant override
Allow a per-tenant policy:
- qbo_item_mode: NON_INVENTORY_ONLY | MIXED | INVENTORY
- (default: NON_INVENTORY_ONLY)
