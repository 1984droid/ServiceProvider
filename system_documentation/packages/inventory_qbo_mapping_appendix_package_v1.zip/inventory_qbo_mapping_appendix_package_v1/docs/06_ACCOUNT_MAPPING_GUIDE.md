# 06 Account Mapping Guide (Keep accounting happy)

This is intentionally policy-driven because accounting preferences differ.

## Minimum required mapping configuration per tenant
- parts_income_account (for parts sales)
- labor_income_account (for labor/services)
- parts_cogs_account (optional for margin reporting)
- core_deposit_account (income or liability-style account per accountant preference)

## Practical v1 recommendation
- Treat core deposit as an income line with a corresponding credit memo on return.
This is operationally simple and common in many shops.

## If accountant wants liability treatment
Implement as a separate configuration:
- core_deposit_account_type = LIABILITY
This may require a different posting strategy (potentially journal entry) depending on QBO constraints.
Keep this as Phase 2 if needed—don’t block go-live.
