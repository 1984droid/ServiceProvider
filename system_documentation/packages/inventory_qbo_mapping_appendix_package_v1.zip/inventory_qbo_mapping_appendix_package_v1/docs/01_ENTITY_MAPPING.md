# 01 Entity Mapping (Local → QBO)

## Lists
- Vendor → QBO Vendor
- CustomerAccount → QBO Customer
- Part → QBO Item

## AR / Sales
- Invoice → QBO Invoice
- POS cash sale:
  - either QBO SalesReceipt (recommended for immediate payment)
  - OR Invoice + Payment allocation (if you want uniformity)

- Customer core refund:
  - CreditMemo (linked to original invoice where possible)

## AP / Purchasing
- VendorBill → QBO Bill
- VendorCredit → QBO VendorCredit
- BillPayment (optional) → QBO BillPayment

## Notes
- Use mapping table + SyncToken to update entities safely.
- Prefer push-first mode; treat QBO as accounting system-of-record for GL/bank rec.
