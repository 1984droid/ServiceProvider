# 03 Core Deposit Pattern (Customer + Vendor)

## What the app tracks (source of truth)
Your CoreLedgerEvent tracks obligations:
- CUSTOMER owes core returns
- VENDOR owes core credits / you owe vendor returns

QBO is the accounting record; we sync financial documents.

---

## Customer core deposit workflow (recommended)
1) When reman part is sold:
   - invoice includes two lines:
     A) reman part line (PART)
     B) core deposit line (CORE_DEPOSIT) using a dedicated QBO Item (non-inventory)
   - CoreLedgerEvent(CUSTOMER, CORE_CHARGED, qty=1)

2) When customer returns the core:
   - record CoreLedgerEvent(CUSTOMER, CORE_RETURNED)
   - issue CreditMemo (or RefundReceipt) for the deposit line
   - CoreLedgerEvent(CUSTOMER, CORE_CREDIT_ISSUED) when credit is finalized

This makes it easy to reconcile: the deposit is refunded only after return.

---

## Vendor core credit workflow (recommended)
1) When you buy reman part:
   - vendor bill may include core charge lines (or be netted later)
   - record CoreLedgerEvent(VENDOR, CORE_CHARGED)

2) When you ship cores back:
   - record CoreLedgerEvent(VENDOR, CORE_RETURNED)
   - vendor issues VendorCredit:
     - sync VendorCredit to QBO
   - record CoreLedgerEvent(VENDOR, CORE_CREDIT_ISSUED)

---

## Policy decisions to expose
- core_due_days default
- partial returns
- writeoff rules (CORE_WRITEOFF)
