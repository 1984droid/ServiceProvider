# 04 Purchase Orders Policy

## Default v1 stance
Do NOT sync PurchaseOrders to QBO.
Reasons:
- Many customers don't use QBO POs consistently.
- Sync adds complexity without immediate value.
- Your internal PO/receiving workflow is richer (special orders, bin receiving, reservations).

## When to consider PO sync
If a tenant strongly relies on QBO for procurement approvals:
- add opt-in PO sync mode
- ensure mapping between internal PO and QBO PurchaseOrder
- treat POs as non-posting documents (they are operational requests)

Even with PO sync enabled:
- receiving and vendor bills remain the main financial sync.
