# 00 QBO Sync Modes (Choose per tenant)

## Mode A — FINANCIAL_ONLY (recommended v1)
- Your app tracks inventory by location (warehouse/truck/bin).
- You sync to QBO:
  - Vendors
  - Customers
  - Items (parts/services as QBO items)
  - Bills / VendorCredits
  - Invoices / SalesReceipts / CreditMemos
  - Payments / BillPayments (optional)
- You DO NOT sync:
  - on-hand qty by bin
  - transfers
  - cycle count adjustments

Why:
- QBO inventory is not location-aware at your level of granularity.
- Syncing quantities creates mismatches and support burden.

## Mode B — QTY_ON_HAND_AGGREGATE (future opt-in)
- QBO tracks one "virtual" quantity on hand for each part.
- Your system periodically pushes an aggregated on-hand quantity (sum across locations).
- Requires additional reconciliation logic and clear ownership rules.

## Subscription reality
Some QBO subscriptions may not support inventory quantity tracking (tests often show differences by plan).
Design your integration to work even if inventory item type is unavailable.
