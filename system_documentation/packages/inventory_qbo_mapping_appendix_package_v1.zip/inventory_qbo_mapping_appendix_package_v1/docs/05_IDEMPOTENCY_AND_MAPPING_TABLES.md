# 05 Idempotency + Mapping Tables (No duplicates, ever)

## Mapping table
QBOMapping rows:
- tenant_id
- entity_type (VENDOR, CUSTOMER, ITEM, BILL, INVOICE, SALESRECEIPT, PAYMENT, CREDITMEMO, VENDORCREDIT)
- local_id
- qbo_id
- qbo_sync_token
- last_synced_at

## Outbox events
When you create/issue:
- Invoice / SalesReceipt
- VendorBill / VendorCredit
- CreditMemo
write OutboxEvent rows, process them async with retries.

## Idempotency keys
- unique constraint on (tenant_id, provider, entity_type, local_id, action)
- on retry: if mapping exists, update instead of create

## Handling QBO edits
If accounting edits invoices/bills in QBO:
- record webhook event
- re-fetch entity
- flag local record as "QBO modified" requiring review (v1)
