# 18 Test Plan (Must-have)

## Financial correctness
- Invoice totals = sum lines + taxes - credits
- Payment allocations reduce balance_due correctly
- Credit memos apply correctly
- Void rules enforced

## Permissions
- cost/margin visibility by role
- leasing sharing permissions (work_orders / asset_costs)

## QBO integration
- OAuth connect stores realmId and tokens
- Refresh token flow works
- Push invoice create/update is idempotent
- Push payment create is idempotent
- Webhook handler ignores duplicates and triggers fetch

## Regression suites
- Work order -> invoice conversion does not change existing WO behavior
- POS payment does not create double invoice unless configured
