# 01 Architecture Decisions (Do this or you'll regret it)

## A) Invoices are the billing truth; Work Orders are the execution truth
- Work orders generate suggested invoice lines.
- Invoices are the customer-facing financial record (AR).
- Never treat WorkOrder as the invoice itself.

## B) Dual amounts: cost vs price
- unit_cost / extended_cost supports internal margin and asset spend.
- unit_price / extended_price supports billing and revenue.
- Both matter. Keep them separate.

## C) Asset spend analytics uses AssetCostEvent ledger
- Do not compute asset spend by summing invoices.
- AssetCostEvent includes costs from WO and non-WO sources (insurance, registration, etc.)

## D) QuickBooks Online is accounting system of record
- Your system supports billing workflows and reporting.
- QBO stores accounting, bank rec, and tax filings.
- Sync from your system to QBO for:
  - Customers
  - Items (services/parts)
  - Invoices + payments + credit memos
- Optional pull/webhooks to reflect payments created in QBO.

## E) Money + permissions
Costs and margins are sensitive:
- enforce permission levels early (none/summary/full)
- leasing visibility is always gated by SharingContract
