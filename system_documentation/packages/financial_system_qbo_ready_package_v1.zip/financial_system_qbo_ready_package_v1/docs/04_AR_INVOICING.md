# 04 AR Invoicing (Repair Shop + Leasing + Manual)

## Invoice creation sources
1) From Work Order:
- Draft invoice created from billable WorkOrderItems
- Service writer can adjust (add/remove lines) before issuing

2) From POS:
- Paid ticket can create invoice automatically (optional) or remain as ticket-only for cash sales

3) From Leasing recurring:
- Generated monthly from schedule

4) Manual:
- For special cases, but still structured (line_type + optional noun item)

## Editing rules (recommended)
- DRAFT invoices editable
- ISSUED invoices are immutable; changes are done via:
  - Credit memo
  - Adjustment invoice
  - Void + reissue (with audit log)

## Numbers and uniqueness
- invoice_number must be sequential per tenant (configurable prefix)
- enforce uniqueness with db constraint (tenant_id, invoice_number)

## Aging
Compute aging buckets from issue_date/due_date and payment allocations.
