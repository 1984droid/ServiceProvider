# 03 Data Models (Proposed)

This is an additive financial layer designed to fit your structured WO + vocabulary approach.

## A) Customer / Counterparty
CustomerAccount (per tenant)
- id
- tenant_id
- display_name
- billing_address
- email/phone
- payment_terms (net15/net30/due_on_receipt)
- tax_exempt + exemption id
- external refs (QBO customer id)

## B) AR: Invoices
Invoice
- tenant_id (issuer)
- customer_account_id (payer)
- invoice_number (unique per tenant)
- status: DRAFT/ISSUED/VOID/PAID/PARTIAL
- issue_date, due_date
- currency
- subtotal, tax_total, total, balance_due
- memo / private notes
- source_type: WORK_ORDER, POS, LEASE, MANUAL
- source_id (uuid nullable)
- qbo_sync_status

InvoiceLine
- invoice_id
- line_type: PART/LABOR/SERVICE/CONSUMABLE/FEE/SUBLET
- noun_item_id (optional but recommended)
- description (short; avoid long free text)
- quantity, uom
- unit_price, extended_price
- tax_code_id
- asset_id (optional)
- work_order_item_id (optional)

## C) Payments
Payment
- tenant_id
- customer_account_id
- payment_date
- amount
- method: CASH/CARD/CHECK/ACH/WIRE/OTHER
- reference
- status: RECORDED/REFUNDED/VOID
- qbo_sync_status

PaymentAllocation
- payment_id
- invoice_id
- amount

## D) Credits & Refunds
CreditMemo
- invoice_id optional (or customer-level)
- amount
- reason_code
- issued_at
Refund
- payment_id
- amount
- refunded_at
- method

## E) POS
SalesTicket
- tenant_id
- customer_account_id nullable (walk-in cash sale)
- status: OPEN/PAID/VOID
- created_at, closed_at
SalesTicketLine
- ticket_id
- part_id optional
- noun_item_id optional
- quantity, unit_price, tax_code_id

## F) Leasing recurring
RecurringBillingSchedule
- tenant_id
- customer_account_id
- cadence: MONTHLY/WEEKLY/QUARTERLY
- next_run_date
- auto_issue: bool
- lines template (LeaseChargeTemplate refs)
LeaseChargeTemplate
- schedule_id
- charge_type: LEASE_RENT/LATE_FEE/DAMAGE/FUEL_SURCHARGE/OTHER
- asset_id optional
- amount
- tax_code_id optional

## G) QuickBooks Online Integration
QBOConnection
- tenant_id
- realm_id
- access_token_encrypted
- refresh_token_encrypted
- expires_at
- scopes
- connected_at
- last_success_sync_at
- last_error

QBOMapping
- tenant_id
- entity_type: CUSTOMER/ITEM/INVOICE/PAYMENT/CREDITMEMO/TAXCODE
- local_id
- qbo_id
- qbo_sync_token (for optimistic concurrency)
- last_synced_at

IntegrationEventLog
- tenant_id
- provider: QBO
- direction: PUSH/PULL
- entity_type
- local_id
- status: SUCCESS/FAILED/RETRYING
- payload_hash
- error_message
