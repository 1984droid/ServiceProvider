# 10 Ledger and Asset Spend (Integration)

This section connects the Financial system to the AssetCostEvent ledger from the Work Orders Gold Standard package.

## Asset spend
AssetCostEvent is the analytics source for costs:
- work order completion emits bucketed cost events
- manual asset expenses emit cost events (insurance, registration, tax, etc.)

## Revenue
Invoices track revenue. Do NOT mix cost and revenue into the same table.

## Leasing visibility
Leasing tenants can optionally see asset spend summaries (not required for compliance) via SharingContract permissions.
