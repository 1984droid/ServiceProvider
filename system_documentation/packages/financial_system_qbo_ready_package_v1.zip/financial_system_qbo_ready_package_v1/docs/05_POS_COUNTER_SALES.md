# 05 POS / Counter Sales

## Goals
- Walk-in part sales
- Minimal clicks
- Clean tax calculation and payments

## MVP flow
- Create SalesTicket
- Add lines (part_id preferred; noun_item allowed)
- Compute totals (sub + tax + total)
- Record Payment
- Close ticket as PAID
- Optional: create Invoice and allocate payment to it

## Why keep SalesTicket separate from Invoice?
- POS needs fast iteration and different UX (cash drawer, quick void, etc.)
- Invoices have stricter rules and audit constraints

## Inventory (optional)
Inventory decrement can come later. Start with parts catalog and pricing.
