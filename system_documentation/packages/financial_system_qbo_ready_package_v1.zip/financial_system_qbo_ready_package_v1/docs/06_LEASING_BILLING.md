# 06 Leasing Billing (Recurring)

## Goal
Leasing tenant bills customers for:
- base rent / lease payment
- optional fees (late fees, damage, pickup/delivery)
- optional pass-through costs

## MVP model
RecurringBillingSchedule + LeaseChargeTemplate

## Recurring job
Nightly job:
- For schedules where next_run_date <= today:
  - create Draft Invoice with schedule lines
  - if auto_issue: issue immediately
  - advance next_run_date by cadence

## Asset linkage
LeaseChargeTemplate may reference asset_id so leasing can:
- report revenue per asset
- link charges to asset history

## QBO sync
Generated invoices are synced like any other invoice.
