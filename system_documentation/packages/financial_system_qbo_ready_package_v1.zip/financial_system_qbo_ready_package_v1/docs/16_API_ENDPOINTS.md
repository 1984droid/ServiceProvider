# 16 API Endpoints (Proposed)

## Customers
- GET/POST /api/customers/
- GET/PATCH /api/customers/{id}/

## Invoices
- GET/POST /api/invoices/
- GET/PATCH /api/invoices/{id}/
- POST /api/invoices/{id}/issue
- POST /api/invoices/{id}/void
- POST /api/invoices/{id}/credit-memo

## Payments
- GET/POST /api/payments/
- POST /api/payments/{id}/allocate

## POS
- GET/POST /api/pos/tickets/
- POST /api/pos/tickets/{id}/pay

## Leasing billing
- GET/POST /api/leasing/billing-schedules/
- POST /api/leasing/billing-schedules/{id}/run-now

## QuickBooks
- POST /api/integrations/qbo/connect (start OAuth)
- GET  /api/integrations/qbo/callback (OAuth return)
- GET  /api/integrations/qbo/status
- POST /api/integrations/qbo/sync-now
- POST /api/integrations/qbo/webhook
