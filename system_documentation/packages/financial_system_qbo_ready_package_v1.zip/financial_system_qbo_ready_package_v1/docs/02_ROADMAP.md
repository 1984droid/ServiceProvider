# 02 Roadmap (Implementation Plan)

This roadmap assumes you've implemented (or are implementing) the Work Orders Gold Standard package:
- WorkOrderItem costing/pricing fields
- MaintenanceDueInstance
- AssetCostEvent ledger emission
- Defect resolution (optional)
- AssetMeter (for meter-driven maintenance/compliance)

---

## Phase F1 — AR Foundation (Invoices + Customers + Payments)
### Models
- CustomerAccount
- Invoice (draft/issued/void/paid/partial)
- InvoiceLine (typed)
- Payment + PaymentAllocation
- CreditMemo (optional but strongly recommended)
- Refund (optional)

### Core flows
1) Create invoice from WorkOrder (draft)
2) Issue invoice (freeze key fields; allow revisions via credit/adjustment)
3) Receive payment and allocate to invoices
4) Aging report + statements

Acceptance criteria
- You can bill from work orders
- You can take a payment and show remaining balance

---

## Phase F2 — POS / Counter Sales
### Models
- SalesTicket (POS order)
- SalesTicketLine
- Payment capture (cash/card/check/ACH recorded)

### Flows
- Create a POS ticket
- Take payment
- Convert to invoice (if needed)
- Sync to QBO

Acceptance criteria
- Front counter part sales can be recorded cleanly and taxed

---

## Phase F3 — Leasing Billing (Recurring)
### Models
- RecurringBillingSchedule
- LeaseChargeTemplate
- LeaseInvoiceLink (optional)

### Flow
- nightly/monthly job generates draft invoices for due schedules
- issue automatically or after review
- sync to QBO

Acceptance criteria
- Leasing tenant can invoice monthly for leased assets

---

## Phase F4 — Taxes (MVP)
### Models
- TaxRegion, TaxRate, TaxRule, TaxCode
### Flow
- compute line taxes and invoice totals
- store tax breakdown

Acceptance criteria
- invoices calculate tax reliably and reproducibly

---

## Phase F5 — QuickBooks Online Integration (QBO-ready)
### Models
- QBOConnection per tenant (OAuth2 tokens + realmId)
- QBOMapping (local_id <-> qbo_id) for customer/item/invoice/payment
- Sync jobs + webhook consumer

### Flow
- push invoices and payments to QBO
- optional pull/webhooks for payments created/edited in QBO

Acceptance criteria
- tenant can connect QBO
- invoices created in your system appear in QBO without duplicates

---

## Phase F6 — Reporting + Controls
- Revenue reporting by customer, period, noun category
- Cost/margin reporting by asset and by provider
- Audit log of invoice changes and sync events
