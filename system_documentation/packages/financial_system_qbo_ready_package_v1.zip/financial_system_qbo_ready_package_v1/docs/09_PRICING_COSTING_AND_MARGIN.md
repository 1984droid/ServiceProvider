# 09 Pricing, Costing, Margin

## Repair shop
WorkOrderItems already store:
- unit_cost, unit_price, extended_cost, extended_price
InvoiceLines can reference WorkOrderItems and copy prices at issuance.

## Margin reporting
- Margin is derived from costs on WorkOrderItems and revenue on InvoiceLines.
- Do not trust invoice price to infer costs.

## Leasing
Lease invoices may not have cost-of-goods in the same way.
If desired, you can track asset depreciation separately, but that is not required for MVP billing.
