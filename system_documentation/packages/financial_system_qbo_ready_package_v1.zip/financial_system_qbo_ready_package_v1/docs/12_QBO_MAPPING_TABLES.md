# 12 QBO Mapping Tables

## Core mappings
Your Entity -> QBO Entity
- CustomerAccount -> Customer
- Part/Service (noun-based) -> Item
- Invoice -> Invoice
- Payment -> Payment
- CreditMemo -> CreditMemo
- TaxCode/TaxRate -> TaxCode/TaxRate (if using QBO taxes mapping)

## Mapping record
QBOMapping stores:
- local_id
- qbo_id
- qbo_sync_token (QBO concurrency token)
- last_synced_at

## Notes
- Always store QBO Ids and SyncToken to support updates.
- Use IntegrationEventLog for retries and auditing.
