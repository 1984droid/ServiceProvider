# 19 Runbook (Operations)

## QBO connection troubleshooting
- Token refresh failures: prompt reauth
- 401/403: check scope/realmId and revocation
- Duplicate invoices: check idempotency keys and mapping table

## Sync monitoring
- Dashboard: events processed, last success, last error
- Retry queue count
- Dead-letter after N retries with alert

## Month-end
- Export AR aging
- Export revenue by customer
- Verify QBO matches totals (spot checks)

## Data retention
- Keep invoices + payments indefinitely
- Keep integration logs for at least 90 days (configurable)
