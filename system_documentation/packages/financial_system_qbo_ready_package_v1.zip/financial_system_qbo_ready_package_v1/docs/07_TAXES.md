# 07 Taxes (MVP, QBO-compatible)

## Strategy
Implement a small tax engine that can compute deterministic taxes, but also map cleanly to QuickBooks tax codes.

## Models
- TaxRegion (state/city)
- TaxRate (percent)
- TaxCode (maps to QBO TaxCode, if syncing)
- TaxRule (which tax code applies given region + line_type + product)

## Computation
- Each InvoiceLine selects a TaxCode (explicit or derived)
- Tax is computed and stored at issuance so it never changes later

## QuickBooks note
If tenant uses QBO automated sales tax, you may choose to:
- push tax codes and let QBO calculate
OR
- calculate in your system and push as line-level taxes
Pick one mode per tenant to avoid mismatches.
