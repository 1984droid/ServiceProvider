# 11 QuickBooks Online Integration (QBO-ready)

## Connection model
Each tenant can connect their own QuickBooks Online company using OAuth 2.0.
Tokens are tied to a QuickBooks company identified by realmId.

## Recommended sync mode (v1)
Push-first:
- Your system is source of truth for invoices and payments.
- Push Customers, Items, Invoices, Payments, CreditMemos to QBO.
Optional:
- Webhooks/polling to pull payment status updates from QBO if payments may be recorded there.

## OAuth2 flow
- tenant admin clicks "Connect QuickBooks"
- redirect to Intuit authorization URL
- exchange authorization code for access+refresh tokens
- store realmId, tokens, expiry
- refresh tokens when expired
- handle revocation (requires reauth)

## Webhooks
Use QBO webhooks to get notified when entities change (Invoices, Payments, Customers).
Implement signature verification and idempotency.
