# 17 Migrations & Backfill

## Migration order (recommended)
1) CustomerAccount (if not already present)
2) Invoice + InvoiceLine
3) Payment + Allocation
4) POS (SalesTicket + lines)
5) Leasing schedules
6) Tax tables (if needed)
7) QBOConnection + QBOMapping + IntegrationEventLog + OutboxEvent

## Backfill
- Existing work orders can start generating invoices only after cutover
- No need to backfill historical invoices unless desired

## Rollback safety
- Migrate phase-by-phase
- Keep new fields nullable and default-safe
