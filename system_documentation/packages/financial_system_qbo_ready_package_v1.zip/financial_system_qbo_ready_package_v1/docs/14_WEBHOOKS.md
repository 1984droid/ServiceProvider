# 14 Webhooks

## QuickBooks Online
- Subscribe to Invoice, Payment, Customer changes.
- Webhooks are aggregated notifications; you typically re-fetch entities using the API.

## Minimal implementation (v1)
- Accept webhook payload
- Verify signature (per Intuit docs)
- Record event hash to prevent duplicates
- Trigger a fetch job for the changed entity if you want pull-sync

## Why you might defer webhooks
If you enforce "payments recorded only in your system", webhooks are less critical.
But they are useful if:
- accounting staff enters payments directly in QBO
- you want near real-time payment status updates
