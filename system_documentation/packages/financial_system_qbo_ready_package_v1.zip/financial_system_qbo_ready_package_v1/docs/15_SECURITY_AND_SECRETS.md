# 15 Security and Secrets

## Store tokens safely
- Encrypt access_token and refresh_token at rest
- Never log tokens
- Restrict token visibility to tenant admins

## Refresh tokens
- Refresh tokens when access token expires
- If refresh fails (revoked), mark connection DISCONNECTED and prompt reauth

## Multi-tenant risk
- Never allow one tenant to use another tenant's QBOConnection
- Every sync job must be tenant-scoped

## Audit logs
- Log invoice issuance, voids, credit memos, payments, refunds
- Log QBO sync events (success/failure)
