# 08 Payments, Credits, Refunds

## Payments
- A payment can pay multiple invoices (allocations)
- Support partial payments

## Credits
- Credit memo is the preferred way to adjust an issued invoice
- Credit can be applied to invoice balance or stored on customer account

## Refunds
- Refunds reference original payment when possible

## QuickBooks sync
- Push Payment + allocations to QBO
- Push CreditMemo to QBO
- Optionally ingest QBO payments via webhooks/polling
