# 00 Overview

## Goal
Implement an exceptional, practical financial system that supports:
- repair shop invoicing (from work orders and POS)
- leasing company recurring billing
- unified, queryable asset spend reporting
- QuickBooks Online synchronization per tenant

## Non-goals (v1)
- Full general ledger (GL) / chart of accounts UI
- Bank reconciliation
- Payroll
- Inventory valuation accounting (we support basic parts catalog; true inventory accounting can be added later)
- Automated sales tax filing

## Guiding constraints
- Multi-tenant isolation: each tenant has its own customers, invoices, payments, QBO connection.
- Hard-typed line items: avoid free-text “misc” whenever possible; use your noun/verb/location vocabulary and item types.
- Idempotent sync to QBO: must be retryable without duplicates.
- Immutable audit trail: invoice revisions are tracked; issued invoices are not silently edited.
