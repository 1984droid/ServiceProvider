# 13 Sync Engine and Idempotency

## Why it matters
Sync must be safe to retry. Network errors will happen.

## Outbox pattern (recommended)
When an entity changes (invoice issued, payment recorded):
- write an IntegrationOutboxEvent row
- background worker processes events and calls QBO APIs
- mark event SUCCESS or FAILED with retry policy

## Idempotency strategy
- Unique constraint: (tenant_id, provider, entity_type, local_id, action)
- When pushing to QBO:
  - if QBOMapping exists -> update
  - else -> create and store mapping
- For webhooks:
  - store webhook event hash and ignore duplicates

## Conflict strategy
Default: your system wins (push-first).
If a QBO webhook indicates someone edited an invoice in QBO:
- flag invoice as "QBO modified" and require manual reconciliation (v1)
