# Financial System Package (QBO-ready) — v1

Generated: 2026-02-08

This package is a **build roadmap + schemas + stubs** for implementing a complete, multi-tenant financial system
supporting:

## Repair Shop
- Work Order billing (service + parts + labor + sublet)
- Front counter / POS parts sales
- Invoicing, payments, credits, refunds
- Tax handling (MVP-capable), receivables aging, statements

## Leasing Company
- Recurring lease billing (monthly invoices)
- One-off charges/credits (fees, damage, late fees, adjustments)
- Optional linkage to assets and lease schedules

## Integrations
- **QuickBooks Online**: OAuth2 connection per tenant, push-first invoice/payment sync, webhooks optional
- **Asset spend**: uses AssetCostEvent ledger from the Work Orders Gold Standard package
- **Leasing compliance**: optional visibility to cost summaries via SharingContract permissions
- **Samsara assets**: not implemented here, but hooks included to ingest odometer/hour meters into AssetMeter (for maintenance + compliance)

Core principle:
- Our system is the operational billing/subledger and source of truth for workflow.
- QuickBooks Online is the accounting system-of-record (GL, bank rec, tax filings), synced via integration.

## Contents
- docs/00_OVERVIEW.md
- docs/01_ARCHITECTURE_DECISIONS.md
- docs/02_ROADMAP.md
- docs/03_DATA_MODELS.md
- docs/04_AR_INVOICING.md
- docs/05_POS_COUNTER_SALES.md
- docs/06_LEASING_BILLING.md
- docs/07_TAXES.md
- docs/08_PAYMENTS_CREDITS_REFUNDS.md
- docs/09_PRICING_COSTING_AND_MARGIN.md
- docs/10_LEDGER_AND_ASSET_SPEND.md
- docs/11_QUICKBOOKS_INTEGRATION.md
- docs/12_QBO_MAPPING_TABLES.md
- docs/13_SYNC_ENGINE_IDEMPOTENCY.md
- docs/14_WEBHOOKS.md
- docs/15_SECURITY_AND_SECRETS.md
- docs/16_API_ENDPOINTS.md
- docs/17_MIGRATIONS_BACKFILL.md
- docs/18_TEST_PLAN.md
- docs/19_RUNBOOK.md
- schemas/*.schema.json
- stubs/django_models.py
- stubs/services_pseudocode.md
- stubs/openapi_stub.yaml
- stubs/qbo_sync_pseudocode.md
- stubs/webhook_handler_stub.py

