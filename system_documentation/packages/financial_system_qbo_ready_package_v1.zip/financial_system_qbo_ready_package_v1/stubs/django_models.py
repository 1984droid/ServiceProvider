# Django model skeletons (stubs)
# Adapt names to your project. This is intended as a blueprint.

from django.db import models
from django.utils import timezone

class CustomerAccount(models.Model):
    tenant = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    display_name = models.CharField(max_length=160)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=40, blank=True)
    billing_address_json = models.JSONField(default=dict, blank=True)
    payment_terms = models.CharField(max_length=32, default='due_on_receipt')
    tax_exempt = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

class Invoice(models.Model):
    tenant = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    customer_account = models.ForeignKey(CustomerAccount, on_delete=models.PROTECT, null=True, blank=True)

    invoice_number = models.CharField(max_length=32)
    status = models.CharField(max_length=16, default='DRAFT')
    source_type = models.CharField(max_length=16, default='MANUAL')
    source_id = models.UUIDField(null=True, blank=True)

    issue_date = models.DateField(null=True, blank=True)
    due_date = models.DateField(null=True, blank=True)
    currency = models.CharField(max_length=3, default='USD')

    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    tax_total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    balance_due = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    memo = models.CharField(max_length=240, blank=True)
    private_notes = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['tenant','invoice_number'], name='uq_invoice_number_per_tenant')
        ]

class InvoiceLine(models.Model):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='lines')
    line_type = models.CharField(max_length=16)
    noun_item = models.ForeignKey('work_orders.NounItem', on_delete=models.PROTECT, null=True, blank=True)

    description = models.CharField(max_length=160, blank=True)
    quantity = models.DecimalField(max_digits=10, decimal_places=2, default=1)
    uom = models.CharField(max_length=16, default='each')

    unit_price = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    extended_price = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    tax_code_id = models.CharField(max_length=64, blank=True)
    asset = models.ForeignKey('assets.Asset', on_delete=models.SET_NULL, null=True, blank=True)

    work_order_item_id = models.UUIDField(null=True, blank=True)

class Payment(models.Model):
    tenant = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    customer_account = models.ForeignKey(CustomerAccount, on_delete=models.PROTECT, null=True, blank=True)

    payment_date = models.DateField(default=timezone.now)
    amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    method = models.CharField(max_length=16, default='CASH')
    reference = models.CharField(max_length=80, blank=True)
    status = models.CharField(max_length=16, default='RECORDED')

class PaymentAllocation(models.Model):
    payment = models.ForeignKey(Payment, on_delete=models.CASCADE, related_name='allocations')
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)

class QBOConnection(models.Model):
    tenant = models.OneToOneField('core_tenant.Tenant', on_delete=models.CASCADE)
    realm_id = models.CharField(max_length=32, blank=True)

    access_token_encrypted = models.TextField(blank=True)
    refresh_token_encrypted = models.TextField(blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)

    scopes = models.JSONField(default=list, blank=True)
    status = models.CharField(max_length=16, default='DISCONNECTED')

    connected_at = models.DateTimeField(null=True, blank=True)
    last_success_sync_at = models.DateTimeField(null=True, blank=True)
    last_error = models.TextField(blank=True)

class QBOMapping(models.Model):
    tenant = models.ForeignKey('core_tenant.Tenant', on_delete=models.CASCADE)
    entity_type = models.CharField(max_length=24)
    local_id = models.CharField(max_length=64)
    qbo_id = models.CharField(max_length=64)
    qbo_sync_token = models.CharField(max_length=32, blank=True)
    last_synced_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['tenant','entity_type','local_id'], name='uq_qbo_mapping_local')
        ]
