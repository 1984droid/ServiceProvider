# QBO Sync Pseudocode

## OAuth connect
1) Build authorization URL with scopes
2) Redirect user
3) Handle callback: exchange auth code -> access_token + refresh_token + realmId
4) Store tokens encrypted and expires_at; status=CONNECTED

## Token refresh
- Before API call: if now >= expires_at - buffer -> refresh
- Handle revocation: refresh fails -> DISCONNECTED, require reauth

## Push entities (recommended order)
- CustomerAccount -> QBO Customer
- Items (parts/services) -> QBO Item
- Invoice -> QBO Invoice
- Payment -> QBO Payment
- CreditMemo -> QBO CreditMemo

## Webhooks
- Receive notification for entity change
- Record event hash
- Fetch updated entity from QBO and update local mapping/status as needed
