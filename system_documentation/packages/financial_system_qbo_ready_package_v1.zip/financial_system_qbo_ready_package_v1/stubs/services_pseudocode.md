# Services (Pseudocode)

## invoice_from_work_order(work_order_id)
- load WorkOrder + WorkOrderItems
- select billable items (is_billable == true)
- create Invoice(status=DRAFT, source_type=WORK_ORDER, source_id=work_order.id)
- create InvoiceLines copying qty/uom/unit_price/extended_price and noun/asset refs
- compute totals (subtotal/tax/total/balance_due)

## issue_invoice(invoice_id)
- validate invoice has lines
- set issue_date and due_date (per terms)
- freeze totals and set status=ISSUED
- enqueue QBO sync event if connected

## record_payment(customer_id, amount, method, reference)
- create Payment
- allocate to open invoices oldest-first or explicit allocation
- update invoice balances
- enqueue QBO payment sync

## qbo_push_invoice(invoice_id)
- ensure tenant has QBOConnection + valid token
- if mapping exists -> update; else create
- store QBO Id + SyncToken
- idempotent via mapping + outbox event unique keys

## qbo_refresh_token(tenant)
- if expires_at in past -> refresh using refresh_token
- update access_token and expires_at
- if refresh fails -> mark DISCONNECTED and require reauth
