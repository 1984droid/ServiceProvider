# Webhook handler stub (Python)
# NOTE: signature verification details depend on Intuit docs; implement per official guidance.

from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def qbo_webhook(request):
    payload = request.body
    # 1) verify signature header (per Intuit docs)
    # 2) store payload hash to dedupe
    # 3) enqueue fetch jobs for changed entities
    return HttpResponse(status=200)
