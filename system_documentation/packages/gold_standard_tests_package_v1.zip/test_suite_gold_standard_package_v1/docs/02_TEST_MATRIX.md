# 02 Test Matrix (What to test)

This is the authoritative checklist your agent should implement.

## A) Multi-tenant isolation (SECURITY)
- Creating/reading/updating objects across tenant boundaries is denied
- WorkOrderItem.clean() prevents cross-tenant related_defect linkage
- SharingContract is required for leasing tenant visibility
- Leasing “summary vs full” permissions redact sensitive fields:
  - costs, evidence, internal notes

## B) Work Orders Gold Standard (CORE)
- WorkOrderItem extended_cost/extended_price computed correctly
- WorkOrder totals recompute correctly across create/update/delete
- WorkOrder completion sets timestamps
- MaintenanceDueInstance linking (hybrid):
  - marks DONE only if required meter reading provided
- AssetCostEvent emission on completion:
  - bucketed events are idempotent (no duplicates on retry)
- Defects auto-resolve (MVP) and (if enabled) verification flow

## C) Inspections ↔ Work Orders (SAFETY)
(See integration assessment gaps; these become tests.)
- Proposals generated from defects via mapping
- Fallback proposal generation when mapping missing (if enabled)
- Proposal estimates carry to WorkOrderItems on promotion
- Bulk promote: 10 proposals → 1 work order in one transaction
- Unsafe defect: WO completion sets verification_status REQUIRED
- Recheck inspection sets PASSED/FAILED and affects compliance status
- Evidence references propagate to WO item detail view

## D) Leasing Compliance
- Without SharingContract: leasing sees UNKNOWN / no data
- With SharingContract (summary): leasing sees compliance states and reasons
- With SharingContract (none): leasing cannot see costs/evidence even if it exists
- Compliance snapshots:
  - due soon vs overdue with grace period
  - OOS when unsafe defects open or pending verification
  - provider verification policy respected (if enabled)

## E) Financial system (AR + POS + Leasing Billing)
- Invoice totals = line subtotal + tax - credits
- Issued invoices immutable; changes via credit/adjustment
- Payments allocate across invoices; balance_due correct
- POS ticket:
  - paid ticket issues inventory and creates sales receipt/invoice per policy
- Recurring leasing schedules:
  - generates invoices on next_run_date, advances schedule
- QBO outbox events created on issue/record actions

## F) Inventory management (MULTI-LOCATION)
- Receive increases on_hand at location
- Issue decreases on_hand from location
- Transfer moves qty and preserves totals
- Reserved qty reduces available, not on_hand
- Special order:
  - reserved on receipt for the WO
  - cannot be issued to other jobs
- Cycle count reconcile generates COUNT_ADJUSTMENT transactions
- Min/max suggestions:
  - deterministic, explainable, stable
- Purchasing:
  - PO → partial receipt → vendor bill linkage
  - receipt/bill unit costs traceable to vendor invoice number

## G) Cores (CUSTOMER + VENDOR OBLIGATIONS)
- Core obligation created on sale/issue of reman part
- Core return reduces obligation
- CreditMemo/VendorCredit clears obligation (ledger event)
- Aging report produces correct open_core_qty

## H) QBO sync (IDEMPOTENCY)
- OAuth connect stores realmId + tokens
- Refresh token flow: access token refresh works, revocation handled
- Push invoice/payment/bill is idempotent:
  - retry does not create duplicates
- Webhook handler:
  - verifies signature (stubbed), de-dupes payload hash, enqueues fetch
