# 05 CI Checklist

## Required checks
- Unit + service tests pass
- Integration tests pass (QBO mocked)
- Coverage minimums:
  - services >= 85%
  - integration >= 60%
- No cross-tenant leakage tests failing

## Optional nightly checks
- Slow E2E golden paths
- Property-based ledger invariants (Hypothesis)

## Artifacts
- junit xml
- coverage report
- logs for QBO mock calls (debug)
