# 03 E2E Golden Paths (Few but powerful)

Keep these tests few and stable; they are your “real workflow smoke tests”.

## GP1: Unsafe defect → repair → verification → compliance
1) Create asset + inspection program
2) Run inspection creating UNSAFE defect
3) Generate proposals (with estimates) and bulk-promote into a WO
4) Issue part from truck inventory + complete WO
5) Defect becomes RESOLVED, verification REQUIRED
6) Compliance snapshot shows OUT_OF_SERVICE due to pending verification
7) Run recheck inspection -> verification PASSED
8) Compliance snapshot becomes COMPLIANT
9) Create invoice from WO, issue invoice
10) Record payment and sync outbox event created

## GP2: PM due → work order → due instance DONE → leasing sees compliant
1) Asset has meter reading + maintenance program (interval miles)
2) Create MaintenanceDueInstance due soon
3) Generate PM WO proposal, approve + complete with meter_reading_at_service
4) Due instance marked DONE
5) Leasing tenant with SharingContract sees updated compliance

## GP3: Special order part tied to WO + receiving + vendor bill + QBO sync
1) WO requests special order part
2) Create PO line linked to special order
3) Receive part into special-order staging location
4) Reservation created for WO
5) Issue to WO and complete
6) Vendor bill recorded with invoice number and unit cost
7) Outbox events for QBO bill sync created (mocked)

## GP4: Core deposit flow (customer + vendor)
1) Sell reman part + core deposit line on invoice
2) Core obligation created for customer
3) Customer returns core -> credit memo issued
4) Vendor core obligation created on purchase
5) Vendor returns -> vendor credit clears
