# 04 Debugging Playbook (How to fix failures fast)

## 1) Identify the failure type
### A) Permission/403 failures
- Check tenant_root on created fixtures
- Ensure SharingContract exists and is effective
- Confirm test user role includes permission

### B) Math/totals failures
- Print line items and computed totals
- Ensure recompute service called in tests
- Watch decimal precision and rounding

### C) Schedule/time failures
- Freeze time for due date computations
- Verify timezone handling (use UTC in tests)
- Check grace_period settings in policy fixtures

### D) Ledger/idempotency failures
- Look for missing unique constraints
- Ensure “emit ledger events” uses upsert pattern
- Confirm test calls completion hook twice to assert no duplicates

### E) QBO sync failures (mocking)
- Ensure mock responses include Id and SyncToken
- Ensure mapping table is updated after create
- Confirm retry uses update instead of create

## 2) Reproduce locally
- pytest -k <test_name> -vv
- Add --maxfail=1 --lf to focus

## 3) Use database inspection helpers
- Add debugging prints guarded by env DEBUG_TESTS=1
- Use django_assert_num_queries to catch N+1 issues

## 4) Fix patterns
- Centralize logic in service methods (don’t duplicate in views)
- Use idempotency keys and unique constraints for outbox + ledger
- Add explicit “visibility filter” service for leasing endpoints
