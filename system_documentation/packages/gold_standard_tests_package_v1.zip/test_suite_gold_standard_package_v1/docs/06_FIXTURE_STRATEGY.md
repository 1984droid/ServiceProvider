# 06 Fixture Strategy (Keep tests maintainable)

## Use factories
- TenantFactory
- User/MembershipFactory (with roles)
- AssetFactory
- WorkOrderFactory + WorkOrderItemFactory
- InspectionRunFactory + DefectFactory + ProposalFactory
- MaintenanceProgramFactory + DueInstanceFactory
- InvoiceFactory + PaymentFactory
- PartFactory + LocationFactory + StockFactory
- VendorFactory + POFactory + ReceiptFactory + VendorBillFactory

## Default patterns
- Always set tenant_root explicitly in factories
- Use helper context manager:
  - as_tenant(tenant): ensures queries and created objects are correctly scoped

## Time and schedules
- Use freezegun for:
  - monthly billing run dates
  - maintenance due date calculations
  - grace periods in compliance policy
