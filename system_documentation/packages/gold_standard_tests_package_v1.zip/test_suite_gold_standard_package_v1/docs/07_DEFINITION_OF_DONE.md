# 07 Definition of Done (Test Coverage Targets)

## Minimum pass criteria before pre-live
- All unit + service tests green
- Integration tests green (QBO mocked)
- E2E golden paths green (at least GP1 + GP2)
- Permission suite:
  - no cross-tenant leakage
  - leasing redaction correct
- Ledger invariants:
  - stock never drifts negative without explicit permission
  - no duplicate cost ledger emission on retries
- Snapshot correctness:
  - unsafe pending verification is treated as non-compliant

## Coverage guidance (practical)
- Services layer: >= 85% (this is where business logic lives)
- Views/API: >= 60% (focus on permissions + serialization)
- Models: >= 70% (validations, constraints)
