# 01 Setup and Run

## Recommended tooling
- pytest
- pytest-django
- factory-boy (or model_bakery)
- freezegun (time travel for PM schedules)
- responses or requests-mock (mock QBO HTTP calls)
- coverage.py

## Minimal file layout to add to your repo
- tests/
  - conftest.py
  - factories/
  - unit/
  - services/
  - api/
  - integration/
  - e2e/

## Example commands
Run all tests:
- pytest

Run with more verbosity:
- pytest -vv

Run only integration tests:
- pytest -m integration

Run only a single file:
- pytest tests/services/test_work_order_completion.py

Run a single test by name:
- pytest -k "test_work_order_completion_emits_asset_cost_events"

Run with coverage:
- coverage run -m pytest
- coverage report -m
- coverage html

## Common setup gotchas
- Use Postgres for integration tests (JSON + constraints behave closer to prod)
- Ensure timezone is consistent (UTC) in tests
- Freeze time for schedule-related tests (maintenance due, lease billing schedules)

## Suggested CI pipeline
1) lint + format check
2) unit + service tests
3) integration tests (QBO mocked)
4) optional nightly E2E suite
