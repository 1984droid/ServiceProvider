# 00 Testing Philosophy (Gold Standard)

## What “gold standard” means for your domain
Because this is a **safety auditing + financial + multi-tenant system**, “gold standard” testing means:
- correctness (math, scheduling, state transitions)
- security (tenant isolation, sharing contracts, field-level redaction)
- auditability (append-only ledgers; traceability to documents)
- idempotency (QBO sync and outbox retries must never duplicate)
- explainability (compliance issues must be reproducible)

## Test pyramid (what to emphasize)
1) Unit tests (fast): model validation, pure functions, invariants
2) Service tests (medium): multi-model workflows (WO completion, ledger emission)
3) API tests (medium): permission gates + serialization + validation
4) Integration tests (slower): QBO mocked API, inventory purchasing flows
5) E2E “golden paths” (few, slow): smoke tests replicating real workflows

## Your “red zones” (must be heavily tested)
- cross-tenant visibility (leasing sharing)
- inventory stock math and negative inventory rules
- compliance snapshot correctness (especially unsafe defects verification)
- financial totals, allocations, and issuance immutability
- QBO sync retry/idempotency and token refresh logic
