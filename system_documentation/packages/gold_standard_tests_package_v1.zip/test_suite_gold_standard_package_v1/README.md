# Gold Standard Test Suite Package (v1)

Generated: 2026-02-08

This package is an **agent-ready testing kit** for the systems designed today:

- Work Orders Gold Standard (financials + PM linkage + ledger emission)
- Leasing Compliance Monitoring (SharingContract + compliance snapshots)
- Financial System (QBO-ready AR/POS/leasing billing + sync)
- Inspection ↔ Work Order Gold Enhancements (verification loop, estimates, batching, evidence) 
- Inventory Management Gold Standard (multi-location, purchasing, special orders, core ledger)
- Inventory ↔ QBO mapping appendix (sync modes + item types + core deposit pattern)

It provides:
1) A comprehensive **test matrix** (unit → service → API → integration → E2E)
2) A **runbook** for running tests locally and in CI
3) A **debugging playbook** for fixing failures quickly
4) **pytest/Django test scaffolding** (factories, fixtures, example tests)
5) **invariant tests** for ledgers (inventory, asset cost, cores) and idempotency (QBO outbox)

## Assumptions
- Backend: Django + DRF
- Tests: pytest + pytest-django
- DB: Postgres (recommended), SQLite allowed for unit tests but not integration tests
- Async jobs/outbox: Celery or a background worker pattern (tests include synchronous runner approach)

If your stack differs, use the docs and adapt stubs accordingly.

## Quick Start
1) Install dev deps (example):
   - pip install -r requirements-dev.txt
2) Configure env:
   - DATABASE_URL=postgres://...
   - TEST_DATABASE_URL=postgres://...
3) Run tests:
   - pytest -q
4) Run a focused test:
   - pytest -k "qbo" -q
5) Run integration suite only:
   - pytest -m integration

See docs/01_SETUP_AND_RUN.md for details.

