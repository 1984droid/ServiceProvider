#!/usr/bin/env bash
set -euo pipefail

echo "Helpful commands:"
echo " - Re-run last failures: pytest --lf -vv"
echo " - Stop on first failure: pytest --maxfail=1 -vv"
echo " - Filter by keyword: pytest -k '<keyword>' -vv"
echo " - Print DB state: add temporary print() or use pytest's capsys"
