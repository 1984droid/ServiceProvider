#!/usr/bin/env bash
set -euo pipefail

echo "Running unit + service tests..."
pytest -q -m "not integration and not e2e"

echo "Running integration tests..."
pytest -q -m "integration"

echo "Running e2e smoke tests..."
pytest -q -m "e2e"
