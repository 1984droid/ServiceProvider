from decimal import Decimal

def test_extended_cost_and_price_math(money):
    qty = money(2)
    unit_cost = money(45.50)
    unit_price = money(85.00)

    extended_cost = qty * unit_cost
    extended_price = qty * unit_price

    assert extended_cost == Decimal("91.00")
    assert extended_price == Decimal("170.00")
