import factory
from decimal import Decimal

class WorkOrderFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    tenant_id = factory.Faker("uuid4")
    status = "OPEN"
    internal_cost_total = Decimal("0.00")
    billable_price_total = Decimal("0.00")

class WorkOrderItemFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    quantity = Decimal("1.0")
    uom = "each"
    unit_cost = Decimal("0.00")
    unit_price = Decimal("0.00")
    cost_type = "CUSTOMER_BILLABLE"
    is_billable = True
