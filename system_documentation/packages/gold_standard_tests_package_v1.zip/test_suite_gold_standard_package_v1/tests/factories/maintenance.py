import factory

class MaintenanceProgramFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    program_key = "mp.fleet.tractor.pm_15k"
    interval_miles = 15000

class DueInstanceFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    status = "DUE"
