import factory
from decimal import Decimal

class CustomerFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    name = factory.Faker("company")

class InvoiceFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    status = "DRAFT"
    subtotal = Decimal("0.00")
    tax_total = Decimal("0.00")
    total = Decimal("0.00")
    balance_due = Decimal("0.00")

class PaymentFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    amount = Decimal("0.00")
    method = "CASH"
