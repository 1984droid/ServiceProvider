import factory
from decimal import Decimal

class PartFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    sku = factory.Faker("bothify", text="SKU-#####")
    is_stocked = True
    is_rebuildable = False

class LocationFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    code = factory.Faker("bothify", text="LOC-###")
    location_type = "WAREHOUSE"

class StockFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    on_hand_qty = Decimal("0.0")
    reserved_qty = Decimal("0.0")
