import factory
from django.utils import timezone

# Replace these imports with your actual models
# from core_tenant.models import Tenant
# from users.models import Membership, User

class TenantFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder; replace with Tenant
    id = factory.Faker("uuid4")
    name = factory.Faker("company")
    is_leasing_company = False
    is_repair_shop = False
    created_at = factory.LazyFunction(timezone.now)

class UserFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    email = factory.Faker("email")
