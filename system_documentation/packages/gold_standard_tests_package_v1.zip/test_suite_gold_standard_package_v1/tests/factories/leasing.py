import factory

class SharingContractFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    permissions = {"work_orders":"summary","asset_costs":"none","provider_identity":True}
