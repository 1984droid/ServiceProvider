import factory

class InspectionRunFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    status = "FINALIZED"
    standards_version = "ANSI/SAIA A92.2-2021"
    template_pack_key = "ansi_a92_2_2021"

class DefectFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    status = "OPEN"
    severity = "UNSAFE_OUT_OF_SERVICE"
    verification_status = "NOT_REQUIRED"

class ProposalFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    status = "pending"
