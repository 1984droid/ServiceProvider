import factory

class AssetFactory(factory.Factory):
    class Meta:
        model = dict  # placeholder
    id = factory.Faker("uuid4")
    tenant_id = factory.Faker("uuid4")
    name = factory.Faker("word")
