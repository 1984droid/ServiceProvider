import pytest
from decimal import Decimal

pytest_plugins = [
    "tests.factories.core",
    "tests.factories.assets",
    "tests.factories.work_orders",
    "tests.factories.inspections",
    "tests.factories.maintenance",
    "tests.factories.financial",
    "tests.factories.inventory",
    "tests.factories.leasing",
]

@pytest.fixture
def money():
    # helper for consistent decimals
    return lambda x: Decimal(str(x))

