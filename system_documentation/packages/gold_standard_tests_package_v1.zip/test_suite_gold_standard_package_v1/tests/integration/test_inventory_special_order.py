import pytest

@pytest.mark.integration
def test_special_order_reserved_and_not_consumable_by_other_jobs(db):
    # Create special order request, receive into staging, reservation created for WO
    # Try to issue same part to another WO -> should fail unless override permission
    assert True
